# return the Euclidean distance between two dictionary
# data points from the data set.
def euclidean_distance(data_point1, data_point2):
    distance = ((data_point1["TMAX"] - data_point2["TMAX"])**2 + (data_point1["TMIN"] - data_point2["TMIN"])**2 + (data_point1["PRCP"] - data_point2["PRCP"])**2)**0.5
    return distance

# return a list of data point dictionaries read from the
# specified file.
def read_dataset(filename):
    contents = []
    file = open(filename, "r")
    for line in file:
        splitLine = line.split()
        dictionary = {
            "DATE": splitLine[0],
            "TMAX": float(splitLine[2]),
            "PRCP": float(splitLine[1]),            
            "TMIN": float(splitLine[3]),
            "RAIN": splitLine[4]
        }
        contents.append(dictionary)
    file.close()
    return contents

# return a prediction of whether it is raining or not based
# on a majority vote of the list of neighbors.
def majority_vote(nearest_neighbors):
    trues = 0
    falses = 0
    for data_point in nearest_neighbors:
        if data_point["RAIN"] == "TRUE":
            trues += 1
        else:
            falses += 1
    if trues > falses:
        return "TRUE"
    else:
        return "FALSE"
    
# for sorting distanceDataset lists
def sort(data):
    return data[0]

# using the above functions, return the majority vote
# prediction for whether it's raining or not on the provided test point.
def k_nearest_neighbors(filename, test_point, k):
    dataset = read_dataset(filename)
    distanceDataset = []
    finalDataset = []
    for data in dataset:
        distance = euclidean_distance(test_point, data)
        distanceDataset.append([distance, data])
    distanceDataset.sort(key=sort)
    for i in range(k-1):
        finalDataset.append(distanceDataset[i][1])
    return majority_vote(finalDataset)
