#return a copy of state which fills the jug
#corresponding to the index in which (0 or 1) to
#its maximum capacity. Do not modify state.
def fill(state, max, which):
    newState = state.copy()
    newState[which] = max[which]
    return newState
# return a copy of state which empties the jug
#corresponding to the index in which (0 or 1).
#Do not modify state.
def empty(state, max, which):
    newState = state.copy()
    newState[which] = 0
    return newState
#return a copy of state which pours the contents
#of the jug at index source into the jug at index
#dest, until source is empty or dest is full.
#Do not modify state.
def xfer(state, max, src, dst):
    newState = state.copy()
    newState[dst] += newState[src]
    newState[src] = 0
    if newState[dst] > max[dst]:
        newState[src] = newState[dst] - max[dst]
        newState[dst] = max[dst]
    return newState
#display the list of unique successor states of
#the current state in any order.
def succ(state, max):
    curr = state.copy()
    fill0 = fill(state, max, 0)
    fill1 = fill(state, max, 1)
    empty0 = empty(state, max, 0)
    empty1 = empty(state, max, 1)
    xfer01 = xfer(state, max, 0, 1)
    xfer10 = xfer(state, max, 1, 0)
    states = [curr, fill0, fill1, empty0, empty1, xfer01, xfer10]
    statesNoDups = []
    for sublist in states:
        if sublist not in statesNoDups:
            statesNoDups.append(sublist)
    for st in statesNoDups:
        print(st)
