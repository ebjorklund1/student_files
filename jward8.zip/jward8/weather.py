import math

#return the Euclidean distance between two dictionary data points from the data set
def euclidean_distance(data_point1,data_point2):
    return math.sqrt(math.pow(data_point1['PRCP'] - data_point2['PRCP'],2) + 
    math.pow(data_point1['TMAX'] - data_point2['TMAX'],2) + math.pow(data_point1['TMIN'] - data_point2['TMIN'],2))

#return a list of data point dictionaries read from the specified file.
def read_dataset(filename):
    dataset = [] #list of dictionary entries
    f = open(filename, "r")
    for x in f:
        entry = {
            'DATE': '',
            'PRCP': '',
            'TMAX': '',
            'TMIN': '',
            'RAIN': ''
        }
        data = x.split(" ")
        entry['DATE'] = data[0]
        entry['PRCP'] = float(data[1])
        entry['TMAX'] = float(data[2])
        entry['TMIN'] = float(data[3])
        entry['RAIN'] = data[4].rstrip("\n")
        dataset.append(entry)
    return dataset
#return a prediction of whether it is raining or not based on a majority vote of the list of neighbors
def majority_vote(nearest_neighbors):
    t_votes = 0 #votes for true
    for x in nearest_neighbors:
        if x['RAIN'] == 'TRUE': #only records true votes
            t_votes += 1
    if t_votes > (len(nearest_neighbors)/2): #true votes need to be more than half to have majority
        return 'TRUE'
    else: #otherwise that means there are more votes for false
        return 'FALSE'
#using the above functions, return the majority vote prediction for whether it's raining or not on the
#provided test point.
def k_nearest_neighbors(filename,test_point,k):
    nearest_neighbors = [] #list of tuples that have (distance,index in dataset)
    index = 0
    dataset = read_dataset(filename) 
    
    for x in dataset:
        distance = euclidean_distance(x,test_point)
        entry = (distance,index)
        index += 1 
        if len(nearest_neighbors) < k: #if the list is not full, then add 
            nearest_neighbors.append(entry)
        else: #if list is full, check to see if this entry has closer distance than one in list
            does_fit = False #does it have smaller distance than one in list
            max_entry = nearest_neighbors[0] #entry with biggest distance, to be removed at the end if new entry added
            for x in nearest_neighbors:
                if entry[0] < x[0]: #checks distance
                    nearest_neighbors.append(entry)
                    does_fit = True
                    break
            if does_fit: #only enters if entry was added to list
                for x in nearest_neighbors: #goes through to find the biggest distance
                    if x[0] > max_entry[0]:
                        max_entry = x #update the entry w/ biggest distance
                nearest_neighbors.remove(max_entry) #remove the entry
    
    neighbors = [] #list of dataset entries that correspond to the indices in nearest_neighbors
    for x in nearest_neighbors:
        index = x[1] #index of data in dataset
        neighbors.append(dataset[index]) #add data to list
    return majority_vote(neighbors)