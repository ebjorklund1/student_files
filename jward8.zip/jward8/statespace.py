#return a copy of state which fills the jug corresponding to the index in which (0 or 1) to its maximum capacity. Do not modify state.
def fill(state, max, which):
    copy = state.copy() #makes copy of the state
    copy[which] = max[which]
    return copy

#return a copy of state which empties the jug corresponding to the index in which (0 or 1). Do not modify state.
def empty(state, max, which):
    copy = state.copy()
    copy[which] = 0
    return copy

#return a copy of state which pours the contents of the jug at index source into the jug at index dest, until source is empty or dest is full.
#Do not modify state.
def xfer(state, max, source, dest):
    copy = state.copy()
    if state[source] + state[dest] > max[dest]: #if the two ints are greater than the maximum of the destination
        temp = (copy[source] + copy[dest]) - max[dest] #the difference between the sum and max should be the new source
        copy[dest] = max[dest]
        copy[source] = temp
    else:
        copy[dest] = state[dest] + state[source]
        copy[source] = 0
    return copy
    

#display the list of unique successor states of the current state in any order.
def succ(state, max):
    poss = [] #list of possible succesor states
    poss.append(empty(state,max,0)) #should always be able to empty
    if empty(state,max,1) not in poss: #these if statements are here to make sure successor states aren't repeated
        poss.append(empty(state,max,1))
    if fill(state,max,0) not in poss:
        poss.append(fill(state,max,0))
    if fill(state,max,1) not in poss:
        poss.append(fill(state,max,1))
    if xfer(state,max,0,1) not in poss:
        poss.append(xfer(state,max,0,1))
    if xfer(state,max,1,0) not in poss:
        poss.append(xfer(state,max,1,0))
    for x in poss: #prints all succesor states
        print(x)