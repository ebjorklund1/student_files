#Author: Jeff Hank
#Date: February 3, 2020
#Class: COMP SCI 540 LEC 001
#Assignment: P1 Intro to Python
#Files: p1_statespace.py, p1_weather.py

#fills a jug corresponding to the 'which' parameter and fills it to its max capacity
#state - list which contains the current amount of liquid in the two jugs
#max - list containing the max capacity of each jug
#which - index of which jug to fill
#returns a modified copy of state
def fill(state,max,which):
    newState = state.copy()
    newState[which] = max[which]
    return newState

#empties a jug corresponding to the 'which' parameter
#state - list which contains the current amount of liquid in the two jugs
#max - list containing the max capacity of each jug
#which - index of which jug to empty
#returns a modified copy of state
def empty(state,max,which):
    newState = state.copy()
    newState[which] = 0
    return newState

#transfers the amount of liquid from a source jug into a destination jug
#state - list which contains the current amount of liquid in the two jugs
#max - list containing the max capacity of each jug
#source - index of the source jug
#dest- index of the destination jug
#returns a modified copy of state
def xfer(state,max,source,dest):
    newState = state.copy()
    if(newState[dest]+newState[source] <= max[dest]):
        newState[dest] = newState[dest] + state[source]
        newState[source] = 0
    else:
        newState[dest] = max[dest]
        newState[source] = state[source] - (max[dest]-state[dest])
    return newState

#prints the possible successor states given the current states of each jug
#state - list which contains the current amount of liquid in the two jugs
#max - list containing the max capacity of each jug
def succ(state,max):
    succList = []
    succList.append(state)
    if(state[0] < max[0]):
        tempState = fill(state, max, 0)
        if (tempState not in succList):
            succList.append(tempState)
    if (state[1] < max[1]):
        tempState = fill(state, max, 1)
        if (tempState not in succList):
            succList.append(tempState)
    if(state[0] > 0):
        tempState = empty(state,max,0)
        if(tempState not in succList):
            succList.append(tempState)
    if (state[1] > 0):
        tempState = empty(state, max, 1)
        if (tempState not in succList):
            succList.append(tempState)
    tempState = xfer(state,max,0,1)
    if(state != tempState and tempState not in succList):
        succList.append(tempState)
    tempState = xfer(state,max,1,0)
    if (state != tempState and tempState not in succList):
        succList.append(tempState)

    for item in succList:
        print(item)