#Author: Jeff Hank
#Date: February 3, 2020
#Class: COMP SCI 540 LEC 001
#Assignment: P1 Intro to Python
#Files: p1_statespace.py, p1_weather.py
import math

#finds the euclidean distance between two dictionary data points
#returns the distance between the points as a float
def euclidean_distance(data_point1, data_point2):
    TMAXDist = (data_point1['TMAX'] - data_point2['TMAX'])**2
    PRCPDist = (data_point1['PRCP'] - data_point2['PRCP'])**2
    TMINDist = (data_point1['TMIN'] - data_point2['TMIN'])**2
    return math.sqrt(TMAXDist + PRCPDist + TMINDist)

#reads from a given textfile and outputs a list of data point dictionaries for each line in the file
#filename - name of the file to be read (contains five space-seperated fields: DATE, PRCP, TMAX, TMIN, RAIN)
#returns a list of dictionaries
def read_dataset(filename):
    dataList = []
    with open(filename,'r') as f:
        for line in f:
            stringList = line.split()
            myDict = {'DATE': stringList[0],'TMAX': float(stringList[2]), 'PRCP': float(stringList[1]), 'TMIN': float(stringList[3]), 'RAIN': stringList[4]}
            dataList.append(myDict)
    return dataList

#determines whether a majority of the list entries are raining
#nearest-neighbors - list containing the closest neighbors to an unspecified location
#returns whether the majority of neighbors are raining('TRUE' or 'FALSE')
def majority_vote(nearest_neighbors):
    count = 0
    for item in nearest_neighbors:
        if(item['RAIN']=='TRUE'):
            count += 1
    if(count >= len(nearest_neighbors)/2.0):
        return 'TRUE'
    else:
        return "FALSE"

#determines whether it is raining or not at the test_point by finding its k closest neighbors to see if it is raining there
#filename - name of file to be read
#test_point - point to determine if it's raining or not
#k - integer to find k closest neighbors
#returns a majority vote from test_point's closest k neighbors and determines if it's raining
def k_nearest_neighbors(filename, test_point, k):
    dataList = read_dataset(filename)
    kNearestNeighbors = []
    for index in range(k):
        min = euclidean_distance(test_point,dataList[0])
        nearest = dataList[0]
        for item in dataList:
            if(euclidean_distance(test_point,item) < min):
                min = euclidean_distance(test_point,item)
                nearest = item
                dataList.remove(item)
        kNearestNeighbors.append(nearest)
    return majority_vote(kNearestNeighbors)