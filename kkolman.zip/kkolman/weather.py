import math

def euclidean_distance(dp1, dp2):
    # calculates the euclidean distance between two points

    return math.sqrt(math.pow(dp2['PRCP'] - dp1['PRCP'], 2) + 
                    math.pow(dp2['TMAX'] - dp1['TMAX'], 2) +
                    math.pow(dp2['TMIN'] - dp1['TMIN'], 2))

def read_dataset(fn):
    # reads a file as a list of data points

    ldicts = []
    with open(fn, 'r') as f:
        for line in f.readlines():
            l = line.split()
            ldicts.append({'DATE': l[0], 'PRCP': float(l[1]), 
                           'TMAX': float(l[2]), 'TMIN': float(l[3]), 
                           'RAIN': l[4]})
    return ldicts

def majority_vote(nn):
    # determines the class that represents the majority of the 
    # given data points

    classes = {'TRUE': 0, 'FALSE': 0}
    for n in nn:
        classes[n['RAIN']] += 1

    if classes['TRUE'] == classes['FALSE']:
        return 'TRUE'
    elif classes['TRUE'] > classes['FALSE']:
        return 'TRUE'
    elif classes['TRUE'] < classes['FALSE']:
        return 'FALSE'

def k_nearest_neighbors(fn, tp, k):
    # find the k nearest neighbors by calculating the euclidean
    # distance between the test point and every other point
    # in the dataset, then taking the top k neighbors

    d = read_dataset(fn)
    l = []

    for idx, x in enumerate(d):
        l.append((euclidean_distance(x, tp), idx))
    l = sorted(l, key=lambda x: x[0])

    nn = [d[idx] for x, idx in l]
    return majority_vote(nn[:k])
