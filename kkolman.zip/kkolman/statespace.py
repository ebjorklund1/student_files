def fill(state, m, which):
    # fills one of the jugs completely

    new_state = [x for x in state]
    new_state[which] = m[which]
    return new_state

def empty(state, m, which):
    # empties one of the jugs completely

    new_state = [x for x in state]
    new_state[which] = 0
    return new_state

def xfer(state, m, source, dest):
    # transfer the water from one jug to another

    new_state = [x for x in state]

    # check if transferring will overfill the jar
    if new_state[dest] + new_state[source] > m[dest]:
        new_state[source] -= (m[dest] - new_state[dest])
        new_state[dest] = m[dest]
    else:
        new_state[dest] += new_state[source]
        new_state[source] = 0
    return new_state

def succ(state, m):
    # generate the list of successor states of the given state

    states = []

    # successor states come from either filling a jar, 
    # emptying a jar, or transferring from one jar to another
    for x in [empty(state, m, d) for d in [0,1]]:
        if x not in states:
            states.append(x)
    for x in [fill(state, m, d) for d in [0,1]]:
        if x not in states:
            states.append(x)
    for x in [xfer(state, m, a, b) for a, b in [(0, 1),(1, 0)]]:
        if x not in states:
            states.append(x)
    for s in states:
        print(s)
