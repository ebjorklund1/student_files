# Project Title: p1_statespace
# Project Description: This file simulates the possible states of the bucket problem shown in class. It contains a fill,
#                      empty and transfer methods. It also contains a method to show all possible states based on it's
#                      current state.
# Class and Term: CS540, Spring 2020
# Professor: Jerry Zhu
# Author: Matthew Schmidt

from copy import copy, deepcopy
# This method returns a copy of the parameter state which fills the jug corresponding to the index in which (0 or 1)
# to its maximum capcity based on the parameter max.
#
# param: state - The current states of the two buckets
#        max - The maximum amount of water allowable in each bucket
#        which - Designates which bucket to fill in the current state
# return: A copy of the state with a filled bucket designated by the parameter which
def fill(state, max, which):
    copy_state = state.copy()
    if which == 0:
        copy_state[0] = max[0]
    elif which == 1:
        copy_state[1] = max[1]
    return copy_state

# This method returns a copy of state with an empty jug corresponding to the index in which.
# It uses the max parameter to make sure that this is a valid bucket?
#
# param: state - The current states of the two buckets
#        max - The maximum amount of water allowable in each bucket
#        which - Designates which bucket to fill in the current state
# return: A copy of the state with an empty bucket designated by the parameter which
def empty(state, max, which):
    copy_state = state.copy()
    if which == 0:
        if (state[0] - max[0]) <= 0:
            copy_state[0] = 0
    elif which == 1:
        if (state[1] - max[1]) <= 0:
            copy_state[1] = 0
    return copy_state

# This method returns a copy of state which pours one jug's content (designated by source) into the other jug at
# index dest. This pouring will either result in dest being full or source being empty.
#
# param: state - The current states of the two buckets
#        max - The maximum amount of water allowable in each bucket
#        source - The source of water for pouring
#        dest - tThe other jug to receive the water
# return: A copy of state with the new transferred water in the jugs
def xfer(state, max, source, dest):
    copy_state = state.copy()
    max_dest = max[dest]
    current_source = state[source]
    current_dest = state[dest]
    if (current_source + current_dest) > max_dest:
        copy_state[dest] = max_dest
        copy_state[source] = (current_source + current_dest - max_dest)
    else:
        copy_state[dest] = (current_source + current_dest)
        copy_state[source] = 0
    return copy_state

# This method displays the list of the unique successor states for the parameter state.
#
# param: state - The current states of the two buckets
#        max - The maximum amount of water allowable in each bucket
def succ(state, max):
    unique_state_switch = True
    fill_left = fill(state, max, 0)
    fill_right = fill(state, max, 1)
    empty_left = empty(state, max, 0)
    empty_right = empty(state, max, 1)
    xfer_left_to_right = xfer(state, max, 0, 1)
    xfer_right_to_left = xfer(state, max, 1, 0)
    possibilities = [fill_left, fill_right, empty_left, empty_right, xfer_left_to_right, xfer_right_to_left]
    for i in range(0, len(possibilities)):
        if possibilities[i] != state:
            if (possibilities[i] == fill_left) and (fill_left == fill_right):
                continue
            if(possibilities[i] == empty_left) and (empty_left == empty_right):
                continue
            print("[" + str(possibilities[i][0]) + "," + str(possibilities[i][1]) + "]")
        else:
            if unique_state_switch == True:
                print("[" + str(possibilities[i][0]) + "," + str(possibilities[i][1]) + "]")
                unique_state_switch = False
