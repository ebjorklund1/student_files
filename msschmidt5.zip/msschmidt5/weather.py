# Project Title: p1_weather
# Project Description: This program reads a particular data set file of specific dates and their weather on those dates.
#                       It can take a particular point and determine based on it's nearest neighbors
#                       (weather most similar to the specified point) and determine if it will be raining.
# Class and Term: CS540, Spring 2020
# Professor: Jerry Zhu
# Author: Matthew Schmidt


import math
from copy import copy, deepcopy
#This method returns the Euclidean distance between two dictionary data points based on 'TMAX', 'TMIN', and 'PRCP'.
#
# param:  data_point1 - The first dictionary for the calculation
#         data_point2 - The second dictionary for the calculation
# return: The euclidean distance between the two data points
def euclidean_distance(data_point1, data_point2):
    point_one_max_temp = data_point1['TMAX']
    point_one_min_temp = data_point1['TMIN']
    point_one_prcp = data_point1['PRCP']
    point_two_max_temp = data_point2['TMAX']
    point_two_min_temp = data_point2['TMIN']
    point_two_prcp = data_point2['PRCP']
    distance = (((point_one_max_temp - point_two_max_temp)**2) + ((point_one_min_temp - point_two_min_temp)**2) +
               ((point_one_prcp - point_two_prcp)**2))**0.5
    return distance

# This method reads a file and parses the file into a list of dictionaries.
#
# param:  filename - The file to be read
# return: The list of dictionaries read from the file
def read_dataset(filename):
    dataset = []
    with open(filename, 'r') as f:
        for line in f:
            read_line = line.split(' ')
            read_line_dict = {'DATE': read_line[0], 'PRCP': float(read_line[1]), 'TMAX': float(read_line[2]),
                            'TMIN': float(read_line[3]), 'RAIN': read_line[4]}
            dataset.append(read_line_dict)
    return dataset

# This method returns a prediction of whether its raining at a specific point based on a majority vote of the list
# of its nearest neighbors.
#
# param:  nearest_neighbors - The list of nearest neighbors and their corresponding dictionaries
# return: The majority vote based on the 'RAIN' key found in each dictionary
def majority_vote(nearest_neighbors):
    false_count = 0
    true_count = 0
    for neighbor in nearest_neighbors:
        if (neighbor['RAIN'] == 'TRUE\n') or (neighbor['RAIN'] == 'TRUE'):
            true_count += 1
        else:
            false_count += 1
    if true_count > false_count:
        return 'TRUE'
    else:
        return 'FALSE'

# This method returns the majority vote prediction whether it'r raining or not on the provided test point.
#
# param: filename - The file to be read for calculation of nearest neighbors
#        test_point - The designated test point for rain to be determined
#        k - The number of nearest neighbors to be analyzed
# return: Te majority vote of whether its raining or not based on the nearest neighbors and test point
def k_nearest_neighbors(filename, test_point, k):
    dataset = read_dataset(filename)
    nearest_neighbors_distance = []
    nearest_neighbors_data = []
    i = 0
    for dict in dataset:
        nearest_neighbors_distance.append(euclidean_distance(test_point, dict))
    # This while loop loops through the nearest_neighbors_distance for the smallest value in the data set.
    # That values index is then stored so that the nearest_neighbors_data can be filled with the correct dictionary of
    # the neighbor from dataset and stored in nearest_neighbors_data. To make sure the data is not used again,
    # the distance is reset to be the max of the data plus one.
    while i < k:
        minimum_distance_index = nearest_neighbors_distance.index(min(nearest_neighbors_distance))
        nearest_neighbors_data.append((dataset[minimum_distance_index]).copy())
        dataset[minimum_distance_index] = None
        nearest_neighbors_distance[minimum_distance_index] = max(nearest_neighbors_distance) + 1.0
        i += 1
    return majority_vote(nearest_neighbors_data)