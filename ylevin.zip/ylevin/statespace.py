#return a copy of state which fills the jug corresponding to 
#the index in which (0 or 1) to its maximum capacity. Do not modify state.
def fill(state, max, which):
    if which == 0:
        return [max[0], state[1]]
    if which == 1:
        return [state[0], max[1]]

#return a copy of state which empties the 
#jug corresponding to the index in which (0 or 1). Do not modify state.
def empty(state, max, which):
    if which == 0:
        return [0, state[1]]
    if which == 1:
        return [state[0], 0]

#return a copy of state which pours the contents of the jug at index source 
# into the jug at index dest, 
# until source is empty or dest is full. Do not modify state.
def xfer(state, max, source, dest):
    #Case where more space in dest than water in source
    if state[source] <= (max[dest] - state[dest]):
        if source == 0:
            return [0, state[dest]+state[source]]
        else: 
            return [state[dest]+state[source] , 0]
    
    #Case where more water in source than space in dest
    elif state[source] >= (max[dest] - state[dest]):
        if source == 0:
            return [state[source] - (max[dest] - state[dest]), max[dest]]
        else: 
            return [max[dest], state[source] - (max[dest] - state[dest])]

def succ(state, max):
    #unchanged case
    possibilities = [state]

    #empty jug case
    for i in range(2):
        if state[i] != 0:
            possibilities.append(empty(state,max,i))

    #fill jug case
    for i in range(2):
        if state[i] != max[i]:
            possibilities.append(fill(state, max, i))

    #transfer between jugs case
    for i in range(2):
        if i == 0: otherIndex = 1
        else: otherIndex = 0

        if state[i] != 0 and state[otherIndex] != max[otherIndex]:
            possibilities.append(xfer(state,max,i,otherIndex))

    #print all possibilities
    for possibility in possibilities:
        print(possibility)



