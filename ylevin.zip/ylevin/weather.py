import csv
import math
import heapq

def euclidean_distance(data_point1, data_point2):
    xvals = (data_point1['TMAX'], data_point1['PRCP'], data_point1['TMIN'])
    yvals = (data_point2['TMAX'], data_point2['PRCP'], data_point2['TMIN'])
    return math.sqrt(sum([(a - b) ** 2 for a, b in zip(xvals, yvals)]))

def read_dataset(filename):
    Data = []
    with open(filename) as csvfile:
        reader = csv.DictReader(csvfile,fieldnames=['DATE', 'PRCP', 'TMAX', 'TMIN', 'RAIN'], delimiter = ' ')
        for row in reader:
            dictionary = {}
            row['TMAX'] = float(row['TMAX'])
            row['PRCP'] = float(row['PRCP'])
            row['TMIN'] = float(row['TMIN'])
            reorderedRow = {'DATE': row['DATE'], 'TMAX': row['TMAX'], 'PRCP': row['PRCP'], 'TMIN':row['TMIN'], 'RAIN':row['RAIN']}
            dictionary.update(reorderedRow)
            Data.append(dictionary)
    return Data


def majority_vote(nearest_neighbors):
    counter = 0
    for neighbor in nearest_neighbors:
        if neighbor['RAIN'] == 'TRUE':
            counter = counter + 1
        else:
            counter = counter - 1
    
    if counter >= 0:
        return 'TRUE'
    else:
        return 'FALSE'



def k_nearest_neighbors(filename, test_point, k):
    dataset = read_dataset(filename)
    distVals = []
    index = 0
    for row in dataset:
        distVals.append([index, euclidean_distance(test_point, row)])
        index = index + 1
    
    closestNeighborsIndexes = heapq.nsmallest(k, distVals, key = lambda x : x[1])
    closestNeighbors = []
    for neighbor in closestNeighborsIndexes:
        closestNeighbors.append(dataset[neighbor[0]])

    return majority_vote(closestNeighbors)


