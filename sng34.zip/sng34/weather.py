import heapq
import math


def euclidean_distance(data_point1, data_point2):
    dist = math.sqrt((data_point1["TMAX"] - data_point2["TMAX"])**2 +
                     (data_point1["PRCP"] - data_point2["PRCP"])**2 +
                     (data_point1["TMIN"] - data_point2["TMIN"])**2)
    return dist


def read_dataset(filename):
    list = []
    with open(filename, "r") as f:
        for line in f:
            words = line.split()
            map = {"DATE": words[0], "TMAX": float(words[2]), "PRCP": float(words[1]), "TMIN": float(words[3]), "RAIN": words[4]}
            list.append(map)

    return list


def majority_vote(nearest_neighbors):
    rain = 0
    no_rain = 0
    for i in nearest_neighbors:
        if i["RAIN"] == "TRUE":
            rain += 1
        else:
            no_rain += 1

    if rain >= no_rain: return "TRUE"
    return "FALSE"


def k_nearest_neighbors(filename, test_point, k):
    points = read_dataset(filename)
    heap = []
    for p in points:
        dist = euclidean_distance(test_point, p)
        # date is guaranteed to be unique so avoid comparing dictionaries
        heapq.heappush(heap, (-dist, p["DATE"], p))
        # ensure there are only k nearest neighbors in the priority queue
        if len(heap) > k:
            heapq.heappop(heap)

    list = []
    for a, b, c in heap:
        list.append(c)

    return majority_vote(list)


# def main():
#     print(euclidean_distance({'DATE': '1951-05-19', 'TMAX': 66.0, 'PRCP': 0.0, 'TMIN': 43.0, 'RAIN': 'FALSE'},
#                              {'DATE': '1951-01-27', 'TMAX': 33.0, 'PRCP': 0.0, 'TMIN': 19.0, 'RAIN': 'FALSE'}))
#
#     print(euclidean_distance({'DATE': '2015-08-12', 'TMAX': 83.0, 'PRCP': 0.3, 'TMIN': 62.0, 'RAIN': 'TRUE'},
#                              {'DATE': '2014-05-19', 'TMAX': 70.0, 'PRCP': 0.0, 'TMIN': 50.0, 'RAIN': 'FALSE'}))
#
#     majority = majority_vote([{'DATE': '2015-08-12', 'TMAX': 83.0, 'PRCP': 0.3, 'TMIN': 62.0, 'RAIN': 'TRUE'},
#                               {'DATE': '2014-05-19', 'TMAX': 70.0, 'PRCP': 0.0, 'TMIN': 50.0, 'RAIN': 'FALSE'},
#                               {'DATE': '2014-12-05', 'TMAX': 55.0, 'PRCP': 0.12, 'TMIN': 44.0, 'RAIN': 'TRUE'},
#                               {'DATE': '1954-09-08', 'TMAX': 71.0, 'PRCP': 0.02, 'TMIN': 55.0, 'RAIN': 'TRUE'},
#                               {'DATE': '2014-08-27', 'TMAX': 84.0, 'PRCP': 0.0, 'TMIN': 61.0, 'RAIN': 'FALSE'}])
#     print(majority)
#
#     print(k_nearest_neighbors('rain.txt', {'DATE': '1948-01-01', 'TMAX': 51.0, 'PRCP': 0.47, 'TMIN': 42.0}, 2))
#     print(k_nearest_neighbors('rain.txt', {'DATE': '1948-01-01', 'TMAX': 51.0, 'PRCP': 0.00, 'TMIN': 42.0}, 2))
#     print(k_nearest_neighbors('rain.txt', {'DATE': '1948-01-01', 'TMAX': 51.0, 'PRCP': 0.00, 'TMIN': 42.0}, 10))
#     print(k_nearest_neighbors('rain.txt', {'DATE': '1948-01-01', 'TMAX': 51.0, 'PRCP': 0.05, 'TMIN': 42.0}, 10))
#
# main()