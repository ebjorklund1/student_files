def fill(state, max, which):
    # check if the cup at max capacity
    if state[which] >= max[which]:
        return state
    new_list = state.copy()
    new_list[which] = max[which]
    return new_list


def empty(state, max, which):
    # check if cup has no water
    if state[which] <= 0:
        return state
    new_list = state.copy()
    new_list[which] = 0
    return new_list


def xfer(state, max, source, dest):
    if state[dest] >= max[dest] or state[source] <= 0:
        return state
    new_list = state.copy()
    amount = max[dest] - new_list[dest]
    if new_list[source] >= amount:
        new_list[dest] += amount
        new_list[source] = new_list[source] - amount
    else:
        new_list[dest] += new_list[source]
        new_list[source] = 0
    return new_list

def succ(state, max):
    # display current state
    print(state)
    # display fill and empty states
    for i in range(len(state)):
        if state[i] >= 0 and state[i] < max[i]:
            print(fill(state, max, i))
        if state[i] > 0:
            print(empty(state, max, i))

    # display xfer state(s)
    if(state[0] > 0 and state[1] < max[1]):
        print(xfer(state, max, 0, 1))
    if(state[1] > 0 and state[0] < max[0]):
        print(xfer(state, max, 1, 0))


# def main():
#     max = [5, 7]
#     s0 = [2, 2]
#     print(fill(s0, max, 1))
#     print(s0)
#     s1 = fill(s0, max, 1)
#     print(s1)
#     print(xfer(s1, max, 1, 0))
#     print("----------------------")
#     succ(s0, max)
#
# main()
