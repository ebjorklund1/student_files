# Author: Alex Lehmkuhl
# Project: P1
# File: p1_weather.py

import math

# Returns the euclidean distance between two dictionary data points
# data_point1 The first data point
# data_point2 The second data point
def euclidean_distance(data_point1, data_point2):
    return math.sqrt(
        (data_point2['TMAX'] - data_point1['TMAX']) ** 2 + 
        (data_point2['TMIN'] - data_point1['TMIN']) ** 2 + 
        (data_point2['PRCP'] - data_point1['PRCP']) ** 2
    )

# Returns a list of data point dictionaries read from the specified file
# filename The name of the file to read dictionaries from
def read_dataset(filename):

    # Store the list of datapoints
    result = []
    
    # Open and parse the given file
    with open(filename) as file:
        for line in file:
            elements = line.replace('\n','').split(' ')
            result.append(
                {
                    'DATE': elements[0],
                    'PRCP': float(elements[1]),
                    'TMAX': float(elements[2]),
                    'TMIN': float(elements[3]),
                    'RAIN': elements[4]
                }
            )
            
    
    # Return result
    return result

# Returns a prediction of whether it is raining or not based on a majority
# vote of the list of neighbors
# nearest_neighbors The list of neighbors
def majority_vote(nearest_neighbors):
    
    # Track previous outcomes
    willRain = 0
    wontRain = 0
    
    # Count neighbors' rain outcome
    for neighbor in nearest_neighbors:
        if neighbor['RAIN'] == "TRUE":
            willRain += 1
        else:
            wontRain += 1
          
    # Return result
    return "TRUE" if willRain >= wontRain else "FALSE"

# Returns the majority vote prediction for whether it's raining or not on 
# the provided test point
# filename The name of the file to read data from
# test_point The name of the point to test
# k The number of neighbors to draw conclusions from
def k_nearest_neighbors(filename, test_point, k):
    
    # Get dataset
    dataset = read_dataset(filename)
    
    # List to store k nearest neighbors and distances
    # Start with the first entry
    nearestNeighbors = []
    nearestDistances = []
    
    # Find the next nearest neighbors
    for dataPoint in dataset:
        
        # Store distance from current point to test point
        distanceFromTest = euclidean_distance(dataPoint, test_point)
        
        # Check if this is a better distance than currently stored
        for i in range(len(nearestNeighbors)):
            
            # If we've found a closer neighbor, insert it
            if nearestDistances[i] > distanceFromTest:
                
                nearestNeighbors.insert(i, dataPoint)
                nearestNeighbors = nearestNeighbors[:k]
                
                nearestDistances.insert(i, distanceFromTest)
                nearestDistances = nearestDistances[:k]
                
                break
                
        # If the list is not full, add the item anyway
        else:
            if len(nearestNeighbors) < k:
                nearestNeighbors.append(dataPoint)
                nearestDistances.append(distanceFromTest)
    
    # Return the majority's vote
    return majority_vote(nearestNeighbors)
    

