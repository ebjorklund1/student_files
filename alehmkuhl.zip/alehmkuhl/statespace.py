# Author: Alex Lehmkuhl
# Project: P1
# File: p1_statespace.py


# Fills the chosen item
# state The current state
# max A list containing the maximum values for each item
# which The index of the item to fill
def fill(state, max, which):

    # Create a copy of the current state
    resultState = state[:]
    
    # Set the chosen item to full
    resultState[which] = max[which]
    
    # Return result
    return resultState

# Empties the chosen item
# state The current state
# max A list containing the maximum values for each item
# which The index of the item to empty
def empty(state, max, which):
    
    # Create a copy of the current state
    resultState = state[:]
    
    # Empty the chosen item
    resultState[which] = 0
    
    # Return result
    return resultState

# Transfers the content of the source item to the destination item
# state The current state
# max A list containing the maximum values for each item
# source The index of the source item
# dest The index of the destination item
def xfer(state, max, source, dest):

    # Create a copy of the current state
    resultState = state[:]
 
    # Calculate amount to transfer
    amountTransferred = min(resultState[source], max[dest] - resultState[dest])
    
    # Transfer
    resultState[source] -= amountTransferred
    resultState[dest] += amountTransferred
    
    # Return result
    return resultState

# Returns the list of possible unique successors to the current state
# state The current state
# max A list containing the maximum values for each item
def succ(state, max):

    # Store unique successor states
    successors = []
    
    # Try filling every item
    # Add if it's a unique possible successor state
    for i in range(len(state)):
        newState = fill(state, max, i)
        
        if newState not in successors:
            successors.append(newState)
            
    # Try emptying every item
    # Add if it's a unique possible successor state
    for i in range(len(state)):
        newState = empty(state, max, i)
        
        if newState not in successors:
            successors.append(newState)
            
    # Try transfering to every item
    # Add if it's a unique possible successor state
    for i in range(len(state)):
        for j in range(len(state)):
            
            # Don't try to transfer to the same item
            if i == j:
                continue
                
            newState = xfer(state, max, i, j)
            
            if newState not in successors:
                successors.append(newState)
    
    # Print successor states
    for successor in successors:
        print(successor)

