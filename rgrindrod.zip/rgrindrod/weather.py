import math


# both data points should be dicts that contains 'TMAX' 'TMIN', 'PRCP'
# returns distance between two datapoints where the axis are TMAX TMIN and PRCP
def euclidean_distance(data_point1, data_point2):
    d: float = math.sqrt(
        ((data_point1['TMAX'] - data_point2['TMAX']) ** 2) + ((data_point1['TMIN'] - data_point2['TMIN']) ** 2) + ((
                data_point1['PRCP'] - data_point2['PRCP']) ** 2))
    return d


# reads file line by line, creates a dict for each line, returns list of dicts
def read_dataset(filename):
    file = open(filename)
    data_set = []
    lines = file.readlines()

    for line in lines:
        line_array = line.split()
        data_point = {'DATE': line_array[0], 'PRCP': float(line_array[1]), 'TMAX': float(line_array[2]), 'TMIN': float(line_array[3]),
                      'RAIN': line_array[4]}
        data_set.append(data_point)
    return data_set


# returns true if number of neighbors with rain >= number of neighbors with no rain
def majority_vote(nearest_neighbors):
    num_no_rain = 0
    num_rain = 0
    for neighbor in nearest_neighbors:
        if neighbor['RAIN'] == 'TRUE':
            num_rain = num_rain + 1
        else:
            num_no_rain = num_no_rain + 1
    if num_rain >= num_no_rain:
        return 'TRUE'
    else:
        return 'FALSE'


# reads filename to get data_points
# gets k nearest neighbors to test_point from data_points
# returns prediction for rain for test_point based on the k nearest neighbors
def k_nearest_neighbors(filename, test_point, k):
    def compare(cur_point):
        return euclidean_distance(test_point, cur_point)

    data_set = read_dataset(filename)
    data_set.sort(key=compare)
    data_set = data_set[:k]
    print(data_set)
    return majority_vote(data_set)