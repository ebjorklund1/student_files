# fill <which> jug to max copacity
# state and max are lists that should represent the current and max ammounts of water in each jug
def fill(state, max, which):
    new_state = [state[0], state[1]]
    new_state[which] = max[which]
    return new_state


# empty <which> jug to 0
def empty(state, max, which):
    new_state = [state[0], state[1]]
    new_state[which] = 0
    return new_state


# xfer water from source to dest until dest is at max, or until source has no water left
def xfer(state, max, source, dest):
    new_state = [state[0], state[1]]
    if max[dest] - state[dest] >= state[source]:
        new_state[source] = 0
        new_state[dest] = state[dest] + state[source]
    else:
        new_state[dest] = max[dest]
        new_state[source] = new_state[source] - (max[dest] - state[dest])
    return new_state


# return list of all possible next states
def succ(state, max):
    succs = [fill(state, max, 1), fill(state, max, 0), empty(state, max, 0), empty(state, max, 1),
             xfer(state, max, 0, 1), xfer(state, max, 1, 0)]
    succs = list(set(tuple(sorted(suc)) for suc in succs))
    return succs
