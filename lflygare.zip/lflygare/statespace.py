####
# Lucas Flygare
# p1_statespace.py
#
# The purpose of this class is to figure out if we can get an exact amount of water
# only using and filling up two cups.
#
# Refernces used
# https://docs.python.org/2/library/copy.html # used to properly copy the values of the cups
####
import copy

max = [5, 7]
s0 = [0, 0]

outcomes = list()

# fill one of the cups
def fill(state, max, which):
    hold = copy.copy(state)
    hold[which] = max[which]
    return hold

# empty out one of the desired cups
def empty(state, max, which):
    hold = copy.copy(state)
    hold[which] = 0
    return hold

# transfer the water from one cup to the other
def xfer(state, max, source, dest):
    hold = copy.copy(state)
    x = state[dest] + state[source]
    y = 0
    if (x > max[dest]):
        y = x - max[dest]
        x = max[dest]
    hold[source] = y
    hold[dest] = x
    return hold

# checks if the state is already in the list
def checkIfNotIn(currentList, currentState):
    for i in range(len(currentList)):
        if currentList[i] == currentState:
            return 0
    return 1

# finds all possible outcomes from the current state
def succ(currentState, max):
    # add the original outcome to the list
    outcomes.append(currentState)

    # 6 possible outcomes from the current state
    # fill both cups
    hold = copy.copy(currentState)
    hold = fill(hold, max, 0)
    if checkIfNotIn(outcomes, hold):
        outcomes.append(hold)

    hold = copy.copy(currentState)
    hold = fill(hold, max, 1)
    if checkIfNotIn(outcomes, hold):
        outcomes.append(hold)

    # empty both cups
    hold = copy.copy(currentState)
    hold = empty(hold, max, 0)
    if checkIfNotIn(outcomes, hold):
        outcomes.append(hold)

    hold = copy.copy(currentState)
    hold = empty(hold, max, 1)
    if checkIfNotIn(outcomes, hold):
        outcomes.append(hold)

    # transfer both cups
    hold = copy.copy(currentState)
    hold = xfer(hold, max, 0, 1)
    if checkIfNotIn(outcomes, hold):
        outcomes.append(hold)

    hold = copy.copy(currentState)
    hold = xfer(hold, max, 1, 0)
    if checkIfNotIn(outcomes, hold):
        outcomes.append(hold)

    print(outcomes)