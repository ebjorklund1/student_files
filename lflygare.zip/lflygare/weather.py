####
# Lucas Flygare
# p1_weather.py
#
# The purpose of this class is to read in a weather file and make predictions
# about whether or not it is going to rain.
#
# References used
# https://realpython.com/python-sort/ # used to sort in the k nearest neighbors method
####

import math

#compute the euclidean distance of the two data points
def euclidean_distance(data_point1, data_point2):
    tmax = (float(data_point1["TMAX"]) - float(data_point2["TMAX"])) ** 2
    prcp = (float(data_point1["PRCP"]) - float(data_point2["PRCP"])) ** 2
    tmin = (float(data_point1["TMIN"]) - float(data_point2["TMIN"])) ** 2
    dist = math.sqrt(tmax + prcp + tmin)

    return dist

# read in the text file
def read_dataset(filename):
    weather_list = list()
    f = open(filename, "r")
    for line in f:
        line_split = line.split(" ")
        weather_dict = {"DATE": line_split[0],
                        "TMAX": float(line_split[2]),
                        "PRCP": float(line_split[1]),
                        "TMIN": float(line_split[3]),
                        "RAIN": line_split[4]}
        weather_list.append(weather_dict)

    f.close()
    return weather_list;

# check whether the list has more areas that are raining or not raining
def majority_vote(nearest_neighbors):
    true = 0
    false = 0
    # calculate how many times it is raining and not raining
    for f in nearest_neighbors:
        val = f["RAIN"]
        if val[0] == "T":
            true += 1
        elif val[0] == "F":
            false += 1

    # check if there are more areas that are raining or not raining
    if true >= false:
        return "TRUE"
    else:
        return "FALSE"

# find the closest neighbors to a point by calculating the euclidea distances
def k_nearest_neighbors(filename, test_point, k):
    f = read_dataset(filename)
    dist_list = list()
    # compute all of the euclidean distances
    for i in range(len(f)):
        dist = euclidean_distance(test_point, f[i])
        dict_dist = {"DATE": f[i]["DATE"], "DIST": dist}
        dist_list.append(dict_dist)

    # sort all of the euclidean distances
    sort = sorted(dist_list, key=lambda distance: distance["DIST"])

    # update sort to be k number of values
    sort = sort[:-(len(sort) - k)]

    # this will be a sorted list of of the k closest distances with
    # the boolean of whether or not it will be raining
    sort_bool = list()
    for i in range(len(f)):
        for j in range(len(sort)):
            if f[i]["DATE"] == sort[j]["DATE"]:
                sort_bool.append(f[i])

    return majority_vote(sort_bool)