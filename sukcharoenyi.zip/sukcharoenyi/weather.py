# P1: Introduction to Python
# p1_weather.py
# Name: Oat (Smith) Sukcharoenyingyong
# Net ID: sukcharoenyi@wisc.edu
# CS login: sukcharoenyingyong

import math
# todo: return the Euclidean distance between two dictionary
#  data points from the data set.
def euclidean_distance(data_point1, data_point2):
    # the distance between two points in a 3D plane
    return math.sqrt((data_point2.get('TMAX')-data_point1.get('TMAX'))**2 +
                     (data_point2.get('PRCP')-data_point1.get('PRCP'))**2 +
                     (data_point2.get('TMIN')-data_point1.get('TMIN'))**2)

# todo: return a list of data point dictionaries read from the specified file.
def read_dataset(filename):
    dataset = [ ]
    with open(filename, 'r') as f:
        # for each line in the file
        for line in f:
            # split the values, get rid /n character at the end
            value = line.rstrip().split(" ")
            # create a dictionary for that line
            dataset.append({'DATE': value[0], 'TMAX': float(value[2]),
                          'PRCP': float(value[1]), 'TMIN': float(value[3]),
                          'RAIN': value[4]})

    return dataset

# todo: return a prediction of whether it is raining or not based
#  on a majority vote of the list of neighbors.
def majority_vote(nearest_neighbors):
    # true counter
    t = 0
    # false counter
    f = 0
    # go through all of the dictionaries (data points)
    for x in range(len(nearest_neighbors)):
        # counts how many trues and falses there are
        if nearest_neighbors[x].get('RAIN') == 'TRUE':
            t = t + 1
        elif nearest_neighbors[x].get('RAIN') == 'FALSE':
            f = f + 1
    # if there are more true than falses or an equal amount
    # return 'TRUE' else return 'FALSE'
    if t >= f:
        return 'TRUE'
    elif t < f:
        return 'FALSE'

# todo: using the above functions, return the majority vote prediction
#  for whether it's raining or not on the provided test point.
def k_nearest_neighbors(filename, test_point, k):
    # get the dictionaries (data set)
    dataset = read_dataset(filename)
    # the nearest k neighbors
    near = [ ]
    # distance between each members of the dataset and the test_point
    distance = [ ]
    # get all of the distances stored in a list
    for i in range(len(dataset)):
        distance.append(euclidean_distance(dataset[i], test_point))
    # create list of nearest neighbors
    for j in range(k):
        min_distance = min(distance)
        # get index of minimum distance
        min_index = distance.index(min_distance)
        # add the i'th nearest neighbor onto the list
        near.append(dataset[min_index])
        # remove the minimum distance from the list
        distance.pop(min_index)
        # remove the minimum distance's dataset from the list
        dataset.pop(min_index)

    # call majority_vote on the k nearest neighbors
    return majority_vote(near)

