# P1: Introduction to Python
# p1_statespace.py
# Name: Oat (Smith) Sukcharoenyingyong
# Net ID: sukcharoenyi@wisc.edu
# CS login: sukcharoenyingyong

# todo: return a copy of state which fills the jug corresponding to the index
#  in which (0 or 1) to its maximum capacity. Do not modify state.
def fill(state, max, which):
    # fill index0 jug
    if which == 0:
        return [max[0], state[1]]
    # fill index1 jug
    elif which == 1:
        return [state[0], max[1]]

# todo: return a copy of state which empties the jug corresponding to the index
#  in which (0 or 1). Do not modify state.
def empty(state, max, which):
    # empty index0 jug
    if which == 0:
        return [0, state[1]]
    # empty index1 jug
    elif which == 1:
        return [state[0], 0]

# todo: return a copy of state which pours the contents of the jug at index
#  source into the jug at index dest, until source is empty or dest is full.
#  Do not modify state.
def xfer(state, max, source, dest):
    # amount needed to fill to full for index0 jug
    emp0 = max[0] - state[0]
    # amount needed to fill to full for index1 jug
    emp1 = max[1] - state[1]
    # pour from index0 jug to index1 jug
    if source == 0 and dest == 1:
        # pour all from index0 to index1 if index1 won't spill over
        if emp1 >= state[0]:
            return [0, state[0] + state[1]]
        # pour just enough from index0 to index1 to fill index1
        elif emp1 < state[0]:
            return [state[0] - emp1, state[1] + emp1]
    # pour from index1 jug to index0 jug
    elif source == 1 and dest == 0:
        # pour all from index1 to index0 if index0 won't spill over
        if emp0 >= state[1]:
            return [state[0] + state [1], 0]
        # pour just enough from index1 to index0 to fill index0
        elif emp0 < state[1]:
            return [state[0] + emp0, state[1] - emp0]

# todo: display the list of unique successor states of the current state
#  in any order.
def succ(state, max):
    # all successor states
    s0 = fill(state, max, 0)
    s1 = fill(state, max, 1)
    s2 = empty(state, max, 0)
    s3 = empty(state, max, 1)
    s4 = xfer(state, max, 0, 1)
    s5 = xfer(state, max, 1, 0)
    # list of successor states
    successors = [s0, s1, s2, s3, s4, s5]
    unique = []
    for i in successors:
        if i not in unique:
            unique.append(i)
    print(unique)


