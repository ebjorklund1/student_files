__author__ = 'Samuel Weng'
__email__ = 'sweng23@wisc.edu'
__course__ = 'CS540'
__credits__ = 'none'

def fill(state, max, which):
    temp = [state[0], state[1]]
    if which == 0:
        temp[0] = max[0]
        return temp
    else:
        temp[1] = max[1]
        return temp

def empty(state, max, which):
    temp = [state[0], state[1]]
    if which == 0:
        temp[0] = 0
        return temp
    else:
        temp[1] = 0
        return temp

def xfer(state, max, source, dest):
    temp = [state[0], state[1]]
    # pour from jug 1 to jug 0
    if dest == 0:
        # case where nothing in jug 1 will left
        if (max[0] - temp[0]) >= temp[1]:
            temp[0] += state[1]
            temp[1] = 0
            return temp
        # case where jug 1 will not be empty
        else:
            temp[1] = temp[0] + temp[1] - max[0]
            temp[0] = max[0]
            return temp
    # pour from jug 0 to jug 1
    else:
        # case where nothing in jug 0 will left
        if (max[1] - temp[1]) >= temp[0]:
            temp[1] += state[0]
            temp[0] = 0
            return temp
        # case where jug 0 will not be empty
        else:
            temp[0] = temp[1] + temp[0] - max[1]
            temp[1] = max[1]
            return temp

def succ(state, max):
    # print if haven't print
    print(fill(state, max, 0))
    if fill(state, max, 1) != fill(state, max, 0):
        print(fill(state, max, 1))
    if fill(state, max, 0) != empty(state, max, 0) and fill(state, max, 1) != empty(state, max, 0):
        print(empty(state, max, 0))
    if empty(state, max, 1) != fill(state, max, 0) and empty(state, max, 1) != fill(state, max, 1) and empty(state, max, 1) != empty(state, max, 0):
        print(empty(state, max, 1))
    if xfer(state, max, 0, 1) != fill(state, max, 0) and xfer(state, max, 0, 1) != fill(state, max, 1) and xfer(state, max, 0, 1) != empty(state, max, 0) and xfer(state, max, 0, 1) != empty(state, max, 1):
        print(xfer(state, max, 0, 1)) 
    if xfer(state, max, 1, 0) != fill(state, max, 0) and xfer(state, max, 1, 0) != fill(state, max, 1) and xfer(state, max, 1, 0) != empty(state, max, 0) and xfer(state, max, 1, 0) != empty(state, max, 1) and xfer(state, max, 1, 0) != xfer(state, max, 0, 1):
        print(xfer(state, max, 1, 0))
