__author__ = 'Samuel Weng'
__email__ = 'sweng23@wisc.edu'
__course__ = 'CS540'
__credits__ = 'w3schools.com/python'

import math
def euclidean_distance(data_point1, data_point2):
    # calculate the differences of the 3 values
    n1 = data_point1['TMAX'] - data_point2['TMAX']
    n2 = data_point1['PRCP'] - data_point2['PRCP']
    n3 = data_point1['TMIN'] - data_point2['TMIN']
    # applying the distance formula
    d = math.sqrt(n1*n1 + n2*n2 + n3*n3)
    return d
    
def read_dataset(filename):
    dataset = []
    # read each line in the file
    with open(filename, 'r') as f:
        for line in f:
            array = line.split()
            # store each part of the line as dict
            data = {'DATE': array[0], 'TMAX': float(array[1]), 'PRCP': float(array[2]), 'TMIN': float(array[3]), 'RAIN': array[4]}
            # add all dict into list
            dataset.append(data)
    return dataset

def majority_vote(nearest_neighbors):
    numTrue = 0
    numFalse = 0
    # count number of TRUE in the list of dict
    for x in nearest_neighbors:
        if x['RAIN'] == 'TRUE':
            numTrue += 1
        else:
            numFalse += 1
    # return TRUE if the number of TRUE is the same as the number of FALSE
    if numTrue >= numFalse:
        return 'TRUE'
    else:
        return 'FALSE'

def k_nearest_neighbors(filename, test_point, k):
    dataset = read_dataset(filename)
    distances = []
    data_and_distance = []
    # calculate the distances of all data points to the test point
    for x in range(0, len(dataset) - 1):
        distance = euclidean_distance(dataset[x], test_point)
        distances.append(distance)
        # pair distance and its corresponding data point
        pair = [distances[x], dataset[x]]
        data_and_distance.append(pair)
    # sort the array based on distance
    def takeFirst(a):
        return a[0]
    data_and_distance.sort(key = takeFirst)
    # save only the first k-th elements
    nearest_list = []
    for x in range(k):
        nearest_list.append(data_and_distance[x][1])
    return majority_vote(nearest_list)