import math
from collections import Counter
class weather:

    # This function returns the Euclidean distance
    def euclidean_distance(data_point1, data_point2):
        Dict = data_point1 # stores values from data_point1
        data1 = Dict
        Dict = data_point2 # stores values from data_point2
        data2 = Dict
        euclidean_Distance = math.sqrt( # calculate euclidea distance
            math.pow((data1.get('TMAX') + data2.get('TMAX')), 2) + math.pow((data1.get('PRCP') + data2.get('PRCP')), 2)
            + math.pow((data1.get('TMIN') + data2.get('TMIN')), 2))
        return euclidean_Distance

# This fucntion returns a list of data point dictionaries read from the specified file
def read_dataset(filename):
    #open file and read it into a list
        with open(filename) as f:
            fileList = f.readlines()
            dataSetList = [n.strip().split(" ") for n in fileList] #separate by space
            dictionList = []
            for list in dataSetList:
                data_dict = dict()
                data_dict["DATE"] = str(list[0])
                data_dict["PRCP"] = float(list[1])
                data_dict["TMAX"] = float(list[2])
                data_dict["TMIN"] = float(list[3])
                data_dict["RAIN"] = list[4]
                dictionList.append(data_dict)
            return dictionList

# This function return a prediction of whether it is raining or not based on a majority vote of the list of neighbors
def majority_vote(nearest_neighbors):
        counter = Counter(x['RAIN'] for x in nearest_neighbors if x.get('RAIN'))
        falseCount = counter["FALSE"]
        trueCount = counter["TRUE"]
        if trueCount < falseCount: # Less TRUE than FALSE
            return "FALSE"
        elif trueCount > falseCount: # More True Than FALSE
            return "TRUE"
        else:
            return "TRUE" # Equal AMmount

# This function return the majority vote prediction for whether it's raining or not on the provided test point
def k_nearest_neighbors(filename, test_point, k):
    diction_list = read_dataset(filename)
    euclideanList = []
    return diction_list

