class stateSpace:
    max = [5, 7]
    global jugCurrentState
    jugCurrentState = [0, 0]

# This function return a copy of state which fills the jug corresponding to the index in which (0 or 1) to its maximum capacity
def fill(state, max, which):
    jugCurrentState = state.copy() # copies state
    if which == 1: # If which is 1, the max is 7
        jugCurrentState[1] = max[which]
    else:
        if which == 0: # If which is 0, the max is 5
            jugCurrentState[0] = max[which]
    return jugCurrentState

# This function return a copy of state which empties the jug corresponding to the index in which (0 or 1)
def empty(state, max, which):
    jugCurrentState = state.copy() # copies state
    if which == 1: # If which is 1, 7 is emptied
        jugCurrentState[1] = 0
    else:
        if which == 0: # If which is 0, 5 is emptied
            jugCurrentState[0] = 0
    return jugCurrentState

# This function return a copy of state which pours the contents of the jug at index source into the jug at index dest, until source is empty or dest is full
def xfer(state, max, source, dest):
    jugCurrentState = state.copy() # copies state
    # while one jug is not empty and the other is not full, transfer from 1 to the other
    while jugCurrentState[source] > 0 and jugCurrentState[dest] < max[dest]:
        jugCurrentState[dest] += 1 # add to the destination jug
        jugCurrentState[source] -= 1 # subtract from the source jug
    return jugCurrentState

# This function display the list of unique successor states of the current state in any order.
def succ(state,max):
    successorStates=[]

    s=fill(state,max,0)
    # Checks to see if s is in Successor, if not, append it
    if s not in successorStates:

        successorStates.append(s)

        s=fill(state,max,1)

    if s not in successorStates:

        successorStates.append(s)

        s=empty(state,max,0)

    if s not in successorStates:

        successorStates.append(s)

        s=empty(state,max,1)

    if s not in successorStates:

        successorStates.append(s)

        s=xfer(state,max,0,1)

    if s not in successorStates:

        successorStates.append(s)

        s=xfer(state,max,1,0)

    if s not in successorStates:

        successorStates.append(s)

    return successorStates

