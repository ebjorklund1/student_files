# -*- coding: utf-8 -*-



#fill specified jar to full
def fill(state,max,which):
  new_state = state.copy()
  new_state[which] = max[which]
  return new_state



#empty specified jar
def empty(state,max,which):
  new_state = state.copy()
  new_state[which] = 0
  return new_state




#pour source jar to dest jar until source empty or dest full
def xfer(state, max, source, dest) :
    new_state = state.copy()
    if new_state[dest]+new_state[source] >= max[dest]:
        new_state[dest] = max[dest]
        new_state[source] = state[source]+state[dest]-max[dest]
    else:
        new_state[dest] = state[dest]+state[source]
        new_state[source] = 0
    return new_state




#shows unique list of possible successor of a given state
def succ(state,max):
    List = []
    #all possibilities
    List.append(fill(state, max, 0))
    List.append(fill(state, max, 1))
    List.append(empty(state, max, 0))
    List.append(empty(state, max, 1))
    List.append(xfer(state, max, 0, 1))
    List.append(xfer(state, max, 1, 0))
    result = []
    for i in List:
        if i not in result:
            result.append(i)
    return result