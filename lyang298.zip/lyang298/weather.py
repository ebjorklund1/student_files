# -*- coding: utf-8 -*-
import math
"""
Created on Sun Feb  2 16:01:44 2020

@author: lyang
"""
#calculate euclidean distance between TMAX. PRCP and TMIN of two points
def euclidean_distance(data_point1, data_point2):
    return math.sqrt((data_point1['TMAX'] - data_point2['TMAX'])**2 + (data_point1['PRCP'] - data_point2['PRCP'])**2 + (data_point1['TMIN'] - data_point2['TMIN'])**2)




#read given data file and build into dictionary
def read_dataset(filename) :
    list = []
    with open(filename) as f:
        for line in f:
            d = {}
            line_list = line.split()
            d['DATE'] = line_list[0]
            d['TMAX'] = int(line_list[2])
            d['PRCP'] = float(line_list[1])
            d['TMIN'] = int(line_list[3])
            d['RAIN'] = line_list[4]
            list.append(d)
    return list
            

#majority of "TRUE" and "FALSE" of a list of given points
def majority_vote(nearest_neighbors):
    true_count = 0
    false_count = 0
    for i in nearest_neighbors:
        if i['RAIN'] == 'TRUE':
            true_count += 1
        else:
            false_count +=1
    if true_count >= false_count:
        return str('TRUE')
    else:
        return str('FALSE')
    
    
#find KNN of a given point and find majority vote
def k_nearest_neighbors(filename, test_point, k):
    dataset = read_dataset(filename)
    for i in dataset:
        dist = euclidean_distance(i, test_point)
        i['dist'] = dist
    sorted_list = sorted(dataset, key=lambda k: k['dist'])
    neighbor = sorted_list[:k]
    return majority_vote(neighbor)
    
    
    
    
    
    
    
    
    