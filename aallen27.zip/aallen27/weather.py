# Course: CS 540 Spring 2020
# Date: 2/3/20
# Name: Aniya Allen
# description: Program P1 Weather Program.

import math

#function that calculates the euclidean distance from the two data dictionary points
def euclidean_distance(data_point1, data_point2):
    answer = math.sqrt((data_point1['TMAX'] - data_point2['TMAX']) ** 2 + (data_point1['TMIN'] - data_point2['TMIN']) ** 2)
    return answer

#variable to hold the dictionaries
dict = {}

#the list of dictionaries
list = []

#Reads in a text file line by line and stores each line of dictionaries into a list
def read_dataset(filename):
    with open(filename, 'r') as f:
        for line in f:
            #split each line in the txt file by whitespace
            items = line.split()
            dict = {"DATE": items[0], "TMAX": items[1], "PRCP": items[2], "TMIN": items[3], "RAIN": items[4]}
            list.append(dict)
            # store each line in a dictionary and add it to the list
        return list


#Returns whether most of a location's neighbors are raining or not
def majority_vote(nearest_neighbors):
   rain = 0
   no_rain = 0
   list_length = len(nearest_neighbors)
   for x in range (0,list_length):
       #checks if the majority of neighbors have
       #rain or no rain
       if(nearest_neighbors[x]['RAIN'] == 'TRUE'):
           rain += 1
       else:
           no_rain += 1

   if(rain >= no_rain):
      return True
   else:
      return False

def k_nearest_neighbors(filename, test_point, k):
    list = read_dataset(filename)

