# Course: CS 540 Spring 2020
# # Date: 2/3/20
# # Name: Aniya Allen
# # description: Program P1 that revolves around statespace. The problem to be solved consists of two water jugs of a
# fixed size.

#function that allows you to fill the jugs to capacity from the faucet
def fill(state,max,which):
    state_2 = [i for i in state]
    state_2[which] = max[which]
    #returns a copy of the state, no modification
    return state_2

#empties the entire jug (depending on what index is selected)
def empty(state,max,which):
    state_2 = [i for i in state]
    state_2[which] = 0
    return state_2

#pours water into jug at index source until jug at index dest is full or index source is empty
def xfer(state,max,source,dest):
    state_2 = [i for i in state]
    while state_2[source] > 0 and state_2[dest] < max[dest]:
        state_2[source] -= 1
        state_2[dest] +=1
    return state_2

#Returns list of successor states based on the given state
def succ(state,max):

    succStates=[]
    s1=fill(state,max,0)

    if s1 not in succStates:
        succStates.append(s1)
    s1=fill(state,max,1)

    if s1 not in succStates:
        succStates.append(s1)
    s1=empty(state,max,0)

    if s1 not in succStates:
        succStates.append(s1)
    s1=empty(state,max,1)

    if s1 not in succStates:
        succStates.append(s1)
    s1=xfer(state,max,0,1)

    if s1 not in succStates:
        succStates.append(s1)
    s1=xfer(state,max,1,0)

    if s1 not in succStates:
        succStates.append(s1)
    return succStates

