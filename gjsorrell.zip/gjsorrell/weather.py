import math


def euclidean_distance(data_point1, data_point2):
    distance = math.sqrt(  # calculate euclidean distance with 3 variables
        (float(data_point1["PRCP"]) - float(data_point2["PRCP"])) ** 2 + float(
            (data_point1["TMAX"]) - float(data_point2["TMAX"])) ** 2 + (
                float(data_point1["TMIN"]) - float(data_point2["TMIN"])) ** 2)
    return distance


def read_dataset(filename):
    dict_list = []  # stores separate dictionaries
    f = open(filename, "r")
    for line in f:
        data = line.split()  # separate data by spaces
        dictionary = {"DATE": data[0], "PRCP": float(data[1]), "TMAX": float(data[2]), "TMIN": float(data[3]), "RAIN": data[4]}  # create a
        # dictionary using the known indices
        dict_list.append(dictionary)
    return dict_list


def majority_vote(nearest_neighbors):
    true_count = 0
    false_count = 0
    for neighbor in nearest_neighbors:  # check each nearest neighbor's RAIN value
        if neighbor["RAIN"] == "TRUE":
            true_count += 1
        else:
            false_count += 1
    if true_count >= false_count:  # compare number of true and false
        return "TRUE"
    else:
        return "FALSE"


def sort_by_index(array):  # helper function for sorting by 2nd index
    return array[1]


def k_nearest_neighbors(filename, test_point, k):
    point_list = read_dataset(filename)  # list of points reated by reading the file
    neighbors = []  # list of all key/value pairs, where key is a point and value is distance
    nearest = []  # list of nearest neighbors determined by test point and k value
    for point in point_list:
        neighbors.append([point, euclidean_distance(test_point, point)])
    neighbors.sort(key=sort_by_index)  # sort the list in ascending order
    i = 0
    while i < k:
        nearest.append(neighbors[i][0])  # retrieve and add the k closest data points
        i += 1
    return majority_vote(nearest)  # return a weather prediction based on nearest neighbors
