def fill(state, max, which):
    state = state.copy()
    state[which] = max[which]  # fill the jug up to its respective maximum
    return state


def empty(state, max, which):
    state = state.copy()
    state[which] = 0  # set the respective jug to 0
    return state


def xfer(state, max, source, dest):
    state = state.copy()
    state[dest] += state[source]  # add source to destination
    state[source] = 0
    remainder = state[dest] - max[dest]  # determine if transfer will cause excess
    if remainder > 0:  # if there's an excess, transfer excess back to source
        state[dest] -= remainder
        state[source] += remainder
    return state


def succ(state, max):
    successor = [fill(state, max, 0), fill(state, max, 1),  # calculate every potential successor state
                 empty(state, max, 0), empty(state, max, 1),
                 xfer(state, max, 0, 1), xfer(state, max, 1, 0)
                 ]
    tuple_list = set(map(tuple, successor))  # removing duplicate states from the list found here:
    # https://stackoverflow.com/questions/16827344/how-do-i-remove-duplicate-arrays-in-a-list-in-python
    successor = map(list, tuple_list)
    for index in successor:
        print(index)