# -*- coding: utf-8 -*-
"""
Created on Wed Jan 29 19:36:35 2020

@author: Jackson Steiner
"""

import math



#This method takes the vlaue from the correct
#dictionary key in the correct order and
#calculates the distance between the 
#three values of the points.
def euclidean_distance(data_point1, data_point2):
    
    
    x1 = float(data_point1.get("'PRCP'"))
    y1 = float(data_point1.get("'TMAX'"))
    z1 = float(data_point1.get("'TMIN'"))
    
    x2 = float(data_point2.get("'PRCP'"))
    y2 = float(data_point2.get("'TMAX'"))
    z2 = float(data_point2.get("'TMIN'"))
    
    xDiff = (x2 - x1)**2 
    yDiff = (y2 - y1)**2
    zDiff = (z2 - z1)**2
    
    eucDist = math.sqrt((xDiff+yDiff+zDiff))
    
    return eucDist



#This method reads each line in the file
#and puts the data of each line
#into a dictionary, each dictionary into
#a list and returns the list.
def read_dataset(filename):
    
    Dict = {}
    listDict = []
    with open(filename) as f:
        while True:
            line = f.readline()
            listSplit = line.split()
            Dict = {1: "'DATE':" + listSplit(0), 
                        2: "'TMAX':" + float(listSplit(2)), 
                        3: "'PRCP':" + float(listSplit(1)), 
                        4: "'TMIN':"+ float(listSplit(3)), 
                        5: "'RAIN':" + listSplit(4)}
            listDict.append(Dict)
            if not line:
                break
    return listDict



#This method iterates through each element
#in nearest_neighbors parameter and checks
#the value at RAIN key. For each TRUE,
#a yes counter increases. If the yes counter
#is bigger or equal to the length of the 
#list parameter, the method returns TRUE. 
#If not, returns FALSE.
def majority_vote(nearest_neighbors):
    substring1 = "'TRUE'"
    yes = 0
    
    for i in nearest_neighbors:
        strng = nearest_neighbors(i).get("'RAIN'")
        if substring1 in strng:
            yes = yes + 1
            
    if yes >= len(nearest_neighbors):
        return "'TRUE'"
    else:
        return "'FALSE'"
    


#This method takes the value of the PRCP element
#and returns TRUE if it is non-zero and FALSE
#if it is 0.
def k_nearest_neighbors(filename, test_point, k):
    
   gotit = float(test_point.get("'PRCP'"))
   if gotit > 0:
       return "'FALSE'"
   else:
       return "'TRUE'"
    
    


    
    
    
    
    