# -*- coding: utf-8 -*-
"""
Created on Wed Jan 29 19:36:35 2020

@author: Jackson Steiner
"""
import copy



#This method first checks the value
#of the which parameter. If the value
#of the state, depending on the which value,
#is already full, a list of the original
#state is returned. If not, the state is set
#to the max value.
def fill(state, max, which):
    s0 = copy.deepcopy(state[0])
    s1 = copy.deepcopy(state[1])
    if which == 0:
        if s0 == max[0]:
            return list(state)
        else:
            s0 = max[0]
    elif which == 1:
        if s1 == max[1]:
            return list(state)
        else:
            s1 = max[1]
    stateCopy = [s0, s1]
    return stateCopy



#This method first checks the value
#of the which parameter. If the value
#of the state, depending on the which value,
#is already empty, a list of the original
#state is returned. If not, the state is set
#to the 0.             
def empty(state, max, which):
    s0 = copy.deepcopy(state[0])
    s1 = copy.deepcopy(state[1])
    if which == 0:
        if s0 == 0:
            return list(state)
        else:
            s0 = 0
    elif which == 1:
        if s1 == 0:
            return list(state)
        else:
            s1 = 0
    stateCopy = [s0, s1]
    return stateCopy


 
#This method first checks if the destination
#state is already at max capacity. If so, it
#returns a list of the original state. Next, 
#it checks if the source state is empty. If so,
#it returns a list of the original state. Finally,
#this method checks if transfering would go over
#the destination capacity. If not, it sets the destination
#state to its value plus the current source state value 
#and sets source state to 0. If so, it sets the destination
#to max vlaue and subtracts the value transferred from
#the source state.       
def xfer(state, max, source, dest):
    s0 = copy.deepcopy(state[0])
    s1 = copy.deepcopy(state[1])
    stateCopy = copy.deepcopy(state)
    
    if dest == source:
        stateCopy = [s0, s1]
        return stateCopy
    
    if state[dest] == max:
        stateCopy = [s0, s1]
        return list(state)
    elif state[source] == 0:
        stateCopy = [s0, s1]
        return list(state)
    else:
        if state[source] + state[dest] <= max[dest]:
            stateCopy[dest] = state[source] + state[dest]
            stateCopy[source] = 0
            return stateCopy
        elif state[source] + state[dest] > max[dest]:
            stateCopy[dest] = max[dest]
            stateCopy[source] = state[source] - (max[dest] - state[dest])
            return stateCopy
        


#This method checks if each index in the state
#parameter is at its max value. If it is not, it
#prints out the successor state of each index
# at max value by calling the fill() method. 
#It does the same thing to for the empty case
#but calls empty() instead. Finally, if either
#state is at neither max nor empty, xfer() is 
#called and prints out the possible successor 
#states from that method.
def succ(state, max):
    s0 = copy.deepcopy(state[0])
    s1 = copy.deepcopy(state[1])
    succList = [] 
    
    if s0 != max[0]:
        succList = fill(state, max, 0)
        print(succList)
    if s1 != max[1]:
        succList = fill(state, max, 1)
        print(succList)
    if s0 != 0:
        succList = empty(state, max, 0)
        print(succList)
    if s1 != 0:
        succList = empty(state, max, 1)
        print(succList)
    if s0 != max[0] and s0 != 0:
        if s1 != max[1]:
            succList = xfer(state, max, 0, 1) 
            print(succList)
    if s1 != max[1] and s1 != 0:
        if s0 != max[0]:
            succList = xfer(state, max, 1, 0)
            print(succList)
        
    
     
        
 
    