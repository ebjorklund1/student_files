import math

def euclidean_distance(data_point1, data_point2):
    total = 0
    for i in ['TMAX', 'PRCP', 'TMIN']:
        total += (data_point1[i]-data_point2[i])**2
    return math.sqrt(total)

def read_dataset(filename):
    data = []
    with open(filename, 'r') as f:
        temp = {}
        for line in f:
            temp['DATE'] = line.split(' ')[0]
            temp['TMAX'] = float(line.split(' ')[2])
            temp['PRCP'] = float(line.split(' ')[1])
            temp['TMIN'] = float(line.split(' ')[3])
            temp['RAIN'] = line.split(' ')[4][:-1]
            data.append(temp)
            temp = {}
    return data

def majority_vote(nearest_neighbors):
    false = 0
    true = 0
    for i in nearest_neighbors:
        if i['RAIN'] == 'TRUE':
            true += 1
        else:
            false += 1
    return 'FALSE' if false > true else 'TRUE'

def k_nearest_neighbors(filename, test_point, k):
    data = read_dataset(filename)
    closest_k = []
    for i in data:
        dist = euclidean_distance(test_point, i)
        
        if len(closest_k) >= k:
            for x in closest_k:
                if dist < euclidean_distance(test_point, x):
                    closest_k.insert(closest_k.index(x), i)
                    closest_k.remove(x)
        else:
            closest_k.append(i)
            
    return majority_vote(closest_k)

