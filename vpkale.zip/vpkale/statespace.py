#!/usr/bin/env python
# coding: utf-8

# In[45]:


def fill(state, max, which):
    newState = state.copy()
    newState[which] = max[which]
    return newState

def empty(state, max, which):
    newState = state.copy()
    newState[which] = 0
    return newState

def xfer(state, max, source, dest):
    newState = state.copy()
    newState[dest] = state[dest] + state[source]
    if state[dest] + state[source] > max[dest]:
        newState[dest] = max[dest]
         
    newState[source] = state[source] - (newState[dest] - state[dest])
    if newState[dest] == state[dest]:
        newState[source] = state[source]
    return newState


def succ(state, max):
    temp = []
    for i in [0,1]:
        if fill(state, max, i) not in temp:
            temp.append(fill(state, max, i))
        if empty(state, max, i) not in temp:
            temp.append(empty(state, max, i))
        if xfer(state, max, i, 1-i) not in temp:
            temp.append(xfer(state, max, i, 1-i))
    for i in temp:
        print(i)

