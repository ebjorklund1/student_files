def fill (state, max, which):
    ''' Return copy of state with element at index which is changed to max[which].
    '''
    new_state = state[::]
    new_state[which] = max[which]
    return new_state
    
def empty (state, max, which):
    ''' Return copy of state with element at index which is changed 0.
    '''
    new_state = state[::]
    new_state[which] = 0
    return new_state
    
def xfer (state, max, source, dest):
    ''' Return copy of state with element at index source is transferrde to element at index dest to a upper bound indicated by max[dest].
    '''
    new_state = state[::]
    #If entire contents of src will fit in dest without overflow
    if (state[dest] + state[source]) <= max[dest]:
        new_state[dest] = state[dest] + state[source]
        new_state[source] = 0
    #If there is overflow, only transfer partial amount from src to reach max[dest] at dest
    else:
        new_state[dest] = max[dest]
        new_state[source] = state[source] - (max[dest] - state[dest])
    return new_state

def succ (state, max):
    ''' Display all unique successors from a given state that can be achieved by filling, emptying or transferring between the jugs.
    '''
    next_states = []
    # xfer 0 to 1
    s1 = xfer(state, max, 0, 1)
    next_states.append(s1)
    # xfer 1 to 0
    s2 = xfer(state, max, 1, 0)
    if s2 not in next_states: next_states.append(s2)
    # empty 0
    s3 = empty(state, max, 0)
    if s3 not in next_states: next_states.append(s3)
    # empty 1
    s4 = empty(state, max, 1)
    if s4 not in next_states: next_states.append(s4)
    # fill 0
    s5 = fill(state, max, 0)
    if s5 not in next_states: next_states.append(s5)
    # fill 1
    s6 = fill(state, max, 1)
    if s6 not in next_states: next_states.append(s6)
    
    for i in next_states: print(i)
