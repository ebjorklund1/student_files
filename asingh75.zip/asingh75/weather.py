import math
weather_params = ['DATE', 'PRCP', 'TMAX', 'TMIN', 'RAIN']

def euclidean_distance (data_point1, data_point2):
    ''' Calculate and return euclidean distance between 2 data points. Distance is calculated from 'PRCP', 'TMAX', 'TMIN' keys.
    '''
    x = (data_point1['PRCP'], data_point1['TMAX'], data_point1['TMIN'])
    y = (data_point2['PRCP'], data_point2['TMAX'], data_point2['TMIN'])
    dist = math.sqrt(sum([(a - b) ** 2 for a, b in zip(x, y)]))
    return dist

def read_dataset (filename):
    ''' Read dataset pointed to by filename and return a list of dictionaries with keys from weather_params.
    '''
    dataset = []
    with open(filename) as data_file:
        for line in data_file:
            line_data = line.split()
            for i in range(3):
                line_data[i + 1] = float(line_data[i + 1])
            dataset.append(dict(zip(weather_params, line_data)))
    return dataset
    
def majority_vote (nearest_neighbors):
    ''' Calculate and return majority vote in key 'RAIN' among list of nearest_neighbors.
    '''
    true_count, false_count = 0, 0;
    for i in nearest_neighbors:
        if i['RAIN'] == 'TRUE': true_count += 1
        else : false_count += 1
    if true_count >= false_count: return 'TRUE'
    return 'FALSE'
    
def k_nearest_neighbors (filename, test_point, k):
    ''' Return a prediction for 'RAIN' for test_point based on majority vote of first k neighbors from dataset pointed to by filename.
    '''
    dataset = read_dataset(filename)
    for i in dataset:
        #Add additional 'DIST' key with value of euclidean distance to sort by distances
        i['DIST'] = euclidean_distance(test_point, i)
    #Sort by 'DIST' key to calcualte get nearest neighbors
    dataset.sort(key = lambda k: k['DIST']);
    return(majority_vote(dataset[0:k]))
