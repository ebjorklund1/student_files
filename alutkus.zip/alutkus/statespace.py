#################################################
#  Name: Andrew Lutkus
#  Wisc Email: alutkus@wisc.edu
#  Course: CS540
#  Semester: Spring 2020
#
#  Date: 2/3/2020
#  Files: p1_statespace.py, p1_weather.py
#
#################################################
def fill(state, max, which):
    if which == 0: #first jug
        newstate = [max[0], state[-1]]
    if which == 1: #second jug
        newstate = [state[0], max[-1]]
    return newstate


def empty(state, max, which):
    if which == 0:
        newstate = [0, state[-1]] #set first jug to 0
    if which == 1:
        newstate = [state[0], 0] #set second jug to 0
    return newstate


def xfer(state, max, source, dest):
    if source == 0: #from first jug
        if dest == 0: #to first jug
            return state #do not modify
        if dest == 1: #to second jug
            maxtransfer = max[-1] - state[-1]
            if maxtransfer > state[0]:
                newstate = [state[0] - state[0], state[-1] + state[0]]
            if maxtransfer <= state[0]:
                newstate = [state[0] - maxtransfer, state[-1] + maxtransfer]
    if source == 1: #from second jug
        if dest == 1: #to second jug
            return state #do not modify
        if dest == 0: #to first jug
            maxtransfer = max[0] - state[0]
            if maxtransfer > state[-1]:
                newstate = [state[0] + state[-1], state[-1] - state[-1]]
            if maxtransfer <= state[-1]:
                newstate = [state[0] + maxtransfer, state[-1] - maxtransfer]
    return newstate


def succ(state, max):
    if state[0] == 0 and state[-1] == 0 and max[0] == 0 and max[-1] == 0: #both maxes and jugs are 0
        print(state)
        return
    if state[0] == 0 and max[0] == 0: #first jug and its max are 0
        print(state)
        if state != empty(state, max, 1):
            print(empty(state, max, 1))
        if state != fill(state, max, 1):
            print(fill(state, max, 1))
        return
    if state[-1] == 0 and max[-1] == 0: #second jug and its max are 0
        print(state)
        if state != empty(state, max, 0):
            print(empty(state, max, 0))
        if state != fill(state, max, 0):
            print(fill(state, max, 0))
        return
    if state[0] == 0: #first jug is empty
        if state[-1] == 0: #second jug is also empty
            print(state)
            print(fill(state, max, 0))
            print(fill(state, max, 1))
            return
        elif state[-1] == max[-1]: #second jug is also filled to its max
            print(state)
            print(empty(state, max, 1))
            print(fill(state, max, 0))
            print(xfer(state, max, 1, 0))
            return
        print(state)
        print(empty(state, max, 1))
        print(fill(state, max, 0))
        print(fill(state, max, 1))
        print(xfer(state, max, 1, 0))
        return
    if state[-1] == 0: #second jug is empty
        if state[0] == max[0]: #first jug is also filled to max
            print(state)
            print(empty(state, max, 0))
            print(fill(state, max, 1))
            print(xfer(state, max, 0, 1))
            return
        print(state)
        print(empty(state, max, 0))
        print(fill(state, max, 1))
        print(fill(state, max, 0))
        print(xfer(state, max, 0, 1))
        return
    if state[0] == max[0]: #first jug is filled to max
        if state[-1] == max[-1]: #second jug is also filled to max
            print(state)
            print(empty(state, max, 0))
            print(empty(state, max, 1))
            return
        print(state)
        print(empty(state, max, 0))
        print(empty(state, max, 1))
        print(fill(state, max, 1))
        print(xfer(state, max, 0, 1))
        return
    if state[-1] == max[-1]: #second jug is filled to max
        print(state)
        print(empty(state, max, 1))
        print(empty(state, max, 0))
        print(fill(state, max, 0))
        print(xfer(state, max, 1, 0))
        return
    print(empty(state, max, 0))
    print(empty(state, max, 1))
    print(fill(state, max, 0))
    print(fill(state, max, 1))
    print(xfer(state, max, 0, 1))
    print(xfer(state, max, 1, 0))