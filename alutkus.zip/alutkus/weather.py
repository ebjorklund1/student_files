#################################################
#  Name: Andrew Lutkus
#  Wisc Email: alutkus@wisc.edu
#  Course: CS540
#  Semester: Spring 2020
#
#  Date: 2/3/2020
#  Files: p1_statespace.py, p1_weather.py
#
#################################################
import math


def euclidean_distance(data_point1, data_point2):
    x1 = data_point1["PRCP"]
    y1 = data_point1["TMAX"]
    z1 = data_point1["TMIN"]
    x2 = data_point2["PRCP"]
    y2 = data_point2["TMAX"]
    z2 = data_point2["TMIN"]
    return math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2 + (z1 - z2) ** 2)


def read_dataset(filename):
    file = open(filename, 'r')
    data = file.readlines()
    dictionary = {}
    count = 0
    for line in data:
        tmp = [word.strip() for word in line.split(' ')] #clean up the line
        dictionary[count] = {'DATE': tmp[0], 'TMAX': float(tmp[2]), 'PRCP': tmp[1], 'TMIN': float(tmp[3]),
                             'RAIN': tmp[4]}
        count = count + 1
    file.close()
    return dictionary


def majority_vote(nearest_neighbors):
    truecount = 0
    falsecount = 0
    length = len(nearest_neighbors)
    for i in range(length):
        tmpdic = nearest_neighbors[i]
        if tmpdic["RAIN"] == "TRUE":
            truecount = truecount + 1
        else:
            falsecount = falsecount + 1
    if truecount >= falsecount:
        return "TRUE"
    else:
        return "FALSE"


def k_nearest_neighbors(filename, test_point, k):
    file = open(filename, "r")
    data = file.readlines()
    original_data = {} #contain the original data from the read in file
    distance_list = [None] * len(data) #will contain the list of all the distances
    count = 0
    for line in data:
        tmpline = [word.strip() for word in line.split(' ')] #clean up the line
        tmpdic = {'DATE': tmpline[0], 'TMAX': float(tmpline[2]), 'PRCP': float(tmpline[1]), 'TMIN': float(tmpline[3])}
        original_data[count] = {'DATE': tmpline[0], 'TMAX': float(tmpline[2]), 'PRCP': tmpline[1],
                                'TMIN': float(line[3]), 'RAIN': tmpline[4]}
        distance_list[count] = (euclidean_distance(test_point, tmpdic), count)
        count = count + 1
    distance_list.sort() #sort the list of distances
    majoritydict = {} #will contain a list of the dictionaries of the k nearest neighbors
    for i in range(k):
        majoritydict[i] = original_data[distance_list[i][1]]
    file.close()
    return majority_vote(majoritydict)

