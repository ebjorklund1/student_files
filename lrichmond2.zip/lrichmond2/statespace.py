# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

def fill(state, max, which):
    #sets container in state to maximum based on var which
    if which:
        returnState = [state[0], max[1]]
    else:
        returnState = [max[0], state[1]]
        
    return returnState

def empty(state, max, which):
    #sets container in state to 0 based on var which
    if which:
        returnState = [state[0], 0]
    else:
        returnState = [0, state[1]]
        
    return returnState
        
def xfer(state, max, source, dest):
    #decides which conainer is being transferred from
    if source:
        #if the container is not large enough to fit that is taken into account
        if max[dest] < state[dest] + state[source]:
            returnState = [max[dest], state[source] + state[dest] - max[dest]]
        else:
            returnState = [state[dest] + state[source], 0]
    else:
        if max[dest] < state[dest] + state[source]:
            returnState = [state[source] + state[dest] - max[dest] , max[dest]]
        else:
            returnState = [0, state[dest] + state[source]]
    return returnState
    
def succ(state, max):
    myList = []
    #tries filling both containers and adding them to list
    myList = helper(myList, fill(state, max, 0))
    myList = helper(myList, fill(state, max, 1))
    #tries emptying both containers and adding them to list
    myList = helper(myList, empty(state, max, 0))
    myList = helper(myList, empty(state, max, 1))
    #tries transfering between both containers and adding them to  list
    myList = helper(myList, xfer(state, max, 1, 0))
    myList = helper(myList, xfer(state, max, 0, 1))
    
    for i in range(len(myList)):
        print(myList[i])


def helper(myList, add):
    #helper function checks if state is already present in list
    noAdd = 1
    for i in myList:
        if i == add:
            noAdd = 0
            
    if noAdd:
        myList.append(add)
    
    return myList