# -*- coding: utf-8 -*-
"""
Created on Sat Feb  1 20:11:55 2020

@author: Luke
"""

def euclidean_distance(dict1, dict2):
    #computes given euclidean distance formula
    myNum = ((dict1["TMAX"] - dict2["TMAX"])**2
    + (dict1["TMIN"] - dict2["TMIN"])**2
    + (dict1["PRCP"] - dict2["PRCP"])**2)**.5
     
    return myNum

def read_dataset(myInput):
    #opens file, reads contentsand splits it into tokens based on strings
    file1 = open(myInput, "r")
    myLine = file1.read()
    mySplit = myLine.split()
    
    listDict = []
    Dict = {}
    i = 0
    #fills in a dictionary entry based on read content
    while i < int(len(mySplit)) :
        Dict = {"DATE": mySplit[i], "TMAX": float(mySplit[i+2]),
                "PRCP": float(mySplit[i+1]), "TMIN": float(mySplit[i+3]),
                "RAIN": mySplit[i+4]}
        #adds dictionary entry to array
        listDict.append(Dict)
        i = i + 5
    
    file1.close()
    return listDict

def majority_vote(myDict):
    j = 0
    #checks how many trues are found in the given array
    for i in range(len(myDict)):
        if (myDict[i]["RAIN"] == "TRUE"):
            j += 1
    #decides whether more neighbors were raining
    if len(myDict)/2 <= j :
        return "TRUE"
    else :
        return "FALSE"
    
    
def k_nearest_neighbors(inputFile, dictEntry, k) :
    #reads data
    myData = read_dataset(inputFile)   
    finalPicks = []
    finalPicksScore = []
    finalPicksIndex = []
    #finds k number of neighbors
    for m in range(k):
        found = False
        currLowestScore = float("inf")
        currLowestIndex = float("inf")
        #check if it's the lowest
        for i in range(len(myData)) :
            currData = myData[i]
            currDataScore = euclidean_distance(dictEntry, currData)
            #check if its the score is the new lowest
            if(currDataScore < currLowestScore):
                #Check if it's in the dict already
                for j in range(len(finalPicks)) :
                    if i == finalPicksIndex[j] :
                        found = True
                #changes current lowest score to the found one
                if found != True :
                    currLowestScore = currDataScore
                    currLowestIndex = i
                found = False
        #adds lowest pick to a list of the k neighbors 
        finalPicks.append(myData[int(currLowestIndex)])
        finalPicksScore.append(currLowestScore)
        finalPicksIndex.append(currLowestIndex)
    #returns a majority vote
    return majority_vote(finalPicks)