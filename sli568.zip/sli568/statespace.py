import copy

#fill one of the jug to its max capacity
def fill(state, max, which):
	filledstate = copy.deepcopy(state)              #deep copy to ensure source state being unchanged
	if filledstate[which] == max[which]:    #return none since a filled jug cannot be filled again
		return None
	else:
		filledstate[which] = max[which]
		return filledstate

#empty a jug
def empty(state, max, which):
	emptystate = copy.deepcopy(state)
	emptystate[which] = 0
	return emptystate

#transfer between jugs
def xfer(state, max, source, dest):
	transferstate = copy.deepcopy(state)
	if transferstate[dest] == max[dest] or transferstate[source] == 0:      #invalid move
		return None
	else:
		toMax = max[dest] - transferstate[dest]
		toMin = transferstate[source] - 0
		trans = min(toMax, toMin)                                           #maximum transfer amount
		transferstate[dest] += trans
		transferstate[source] = transferstate[source] - trans
		return transferstate


#successors of a state
def succ(state, max):
	succlist = list()
	for i in range(2):
		if fill(state, max, i) is not None:
			succlist.append(fill(state, max, i))
		if empty(state, max, i) is not None:
			succlist.append(empty(state, max, i))
		if xfer(state, max, i, 1 - i) is not None:
			succlist.append(xfer(state, max, i, 1 - i))
	succlist_set = set(tuple(s) for s in succlist)                          #change to set to prevent duplicate
	succlist = [list(s) for s in succlist_set]
	return succlist



