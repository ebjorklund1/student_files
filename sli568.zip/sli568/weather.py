import heapq
import math
from operator import itemgetter

#calculate error
def euclidean_distance(data_point1, data_point2):
	sum = (data_point1.get('TMAX') - data_point2.get('TMAX')) ** 2 + (
			data_point1.get('PRCP') - data_point2.get('PRCP')) ** 2 + (
			      data_point1.get('TMIN') - data_point2.get('TMIN')) ** 2
	return math.sqrt(sum)


#read data set with assume order of data
def read_dataset(filename):
	data = list()
	try:
		with open(filename, 'r') as file:
			for line in file:
				datalist = line.split(' ')
				dict = {}
				dict['DATE'] = datalist[0]
				dict['PRCP'] = float(datalist[1])
				dict['TMAX'] = float(datalist[2])
				dict['TMIN'] = float(datalist[3])
				dict['RAIN'] = datalist[4]
				data.append(dict)
			file.close()
		return data
	except IOError:
		print("An error occurred while reading ", filename)


#determine raning likehood depends on neibour
def majority_vote(nearest_neighbors):
	score = 0
	for datapoint in nearest_neighbors:     #assign true with 1 and false with -1, and use sum of value to determine
		if datapoint.get('RAIN') == "TRUE\n":   #raining possibility
			score += 1
		else:
			score -= 1
	if score >= 0:
		return 'TRUE'
	else:
		return 'FALSE'


#find first k amount of cases that is similar to a given case
def k_nearest_neighbors(filename, test_point, k):
	data = read_dataset(filename)
	nearst_neigbors = list()
	datawdistance = list()
	for point in data:      #assign value key pair for compariosn
		datawdistance.append({'distance': euclidean_distance(point, test_point), 'data': point})
	sortedList = sorted(datawdistance, key=itemgetter('distance'))          #sort the list
	for i in range(k):
		nearst_neigbors.append(sortedList[i].get('data'))
	return majority_vote(nearst_neigbors)

