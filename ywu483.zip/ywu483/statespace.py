# -*- coding: utf-8 -*-

#returns a copy of state which fills the jug 
#corresponding to the index in which (0 or 1) to its maximum capacity.
#state is not modified

"""
@author: Yuning Wu
ywu483@wisc.edu
"""
import numpy
def fill(state,max,which):
    result = list() #creates an empty list
    
    #fills jug accordingly and puts into the list
    if which == 0:
        result.insert(0,max[0])
        result.insert(1,state[1])
    elif which == 1:
        result.insert(1,max[1])
        result.insert(0,state[0])
    return result #return the list

#returns a copy of state which empties the jug 
#corresponding to the index in which (0 or 1). 
#state is not modified
def empty(state,max,which):
    result = list() #creates an empty list
    
    #empty jug accodingly and puts into the list
    if which == 0:
        result.insert(0,0)
        result.insert(1,state[1])
    elif which == 1:
        result.insert(0,state[0])
        result.insert(1,0)
    return result #return the list

#returns a copy of state which pours the contents of the jug at index source 
#into the jug at index dest, until source is empty or dest is full
#state is not modified
def xfer(state, max, source, dest):
    result = list() #creates an empty list
    
    #if source has more content than the max capacity of dest
    if state[source] >= max[dest]:
        result.insert(0,max[dest])
        result.insert(1,state[source]-max[dest])
        
    #if the max capacity of dest is more than source content
    elif state[source] < max[dest]:
        result.insert(0,state[source])
        result.insert(1,0)
    return result #return the lsit

#displays the list of unique successor states of the current state in any order.
def succ(state,max):
    #result = numpy.array(result)
    result = list() #creates an empty list
    repeat = False #no repeats from the beginning
    
    #calls fill(state,max,which). checks repeats. if not, add to list
    for element in result:
        if(fill(state,max,0) == element):
            repeat = True
            break
    if repeat == False:
        result.append(fill(state,max,0))
    
    #calls fill(state,max,which). checks repeats. if not, add to list
    repeat = False
    for element in result:
        if(fill(state,max,1) == element):
            repeat = True
            break
    if repeat == False:
        result.append(fill(state,max,1))
        
    #calls empty(state,max,which). checks repeats. if not, add to list
    repeat = False
    for element in result:
        if(empty(state,max,0) == element):
            repeat = True
            break
    if repeat == False:
        result.append(empty(state,max,0))
    
    #calls empty(state,max,which). checks repeats. if not, add to list    
    repeat = False
    for element in result:
        if(empty(state,max,1) == element):
            repeat = True
            break
    if repeat == False:
        result.append(empty(state,max,1))
        
    #calls xfer(state,max,source,dest). checks repeats. if not, add to list
    repeat = False
    for element in result:
        if(xfer(state,max,0,1) == element):
            repeat = True
            break
    if repeat == False:
        result.append(xfer(state,max,0,1))
        
    #calls xfer(state,max,source,dest). checks repeats. if not, add to list
    repeat = False
    for element in result:
        if(xfer(state,max,1,0) == element):
            repeat = True
            break
    if repeat == False:
        result.append(xfer(state,max,1,0))
    
    return result #return list

