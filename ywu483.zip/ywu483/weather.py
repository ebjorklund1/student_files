#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Yuning Wu
ywu483@wisc.edu
"""

import math

#return the Euclidean distance between two dictionary data points from the data set.
def euclidean_distance(data_point1, data_point2):
    x1 = data_point1["TMAX"]
    y1 = data_point1["PRCP"]
    z1 = data_point1["TMIN"]
    x2 = data_point2["TMAX"]
    y2 = data_point2["PRCP"]
    z2 = data_point2["TMIN"]
    
    d = math.sqrt(math.pow((x1-x2),2)+math.pow((y1-y2),2)+math.pow((z1-z2),2))
    return d

#return a list of data point dictionaries read from the specified file.
def read_dataset(filename):
    with open(filename) as f:
        for line in f:
            content = f.read().splitlines()
    return content

#return a prediction of whether it is raining or not based on a majority vote of the list of neighbors.
def majority_vote(nearest_neighbors):
    trueNum = 0
    falseNum = 0
    for element in nearest_neighbors:
        if element["RAIN"] == "TRUE":
            trueNum+1
        elif element["RAIN"] == "FALSE":
            falseNum+1
    
    if trueNum >= falseNum:
        return "TRUE"
    else:
        return "FALSE"
    
#using the above functions, return the majority vote prediction for 
#whether it's raining or not on the provided test point.
def k_nearest_neighbors(filename, test_point, k):
    dataset = read_dataset(filename)
    length = len(dataset)
    nearest_neighbors = {}
    for i in range (length):
        distance = euclidean_distance(dataset[i],dataset[i+1])
        nearest_neighbors.append(dataset[1])
        nearest_neighbors.append(dataset[2])
        
    return majority_vote(nearest_neighbors)
    