""""
Sophie Bohr
CS540
Project 1 - Part 1
"""

# return a copy of state which fills the jug corresponding
# to the index in which (0 or 1) to its maximum capacity.
# Do not modify state.
def fill(state, max, which):
    # initialize state_copy
    state_copy = [0, 0]
    # copy state's values over to state_copy
    state_copy[0] = state[0]
    state_copy[1] = state[1]
    # fill the proper jug
    state_copy[which] = max[which]
    # return the new state
    return state_copy


# return a copy of state which empties the jug corresponding
# to the index in which (0 or 1).
# Do not modify state.
def empty(state, max, which):
    # initialize state_copy
    state_copy = [0, 0]
    # copy state's values over to state_copy
    state_copy[0] = state[0]
    state_copy[1] = state[1]
    # empty the proper jug
    state_copy[which] = 0
    # return the new state
    return state_copy


# return a copy of state which pours the contents of the jug
# at index source into the jug at index dest, until source is
# empty or dest is full.
# Do not modify state.
def xfer(state, max, source, dest):
    # initialize state_copy
    state_copy = [0, 0]
    # copy state's values over to state_copy
    state_copy[0] = state[0]
    state_copy[1] = state[1]
    # keep pouring until the source jug is empty or the destination
    # jug is full
    while state_copy[source] > 0 and state_copy[dest] < max[dest]:
        state_copy[source] -= 1
        state_copy[dest] += 1
    # return the new state
    return state_copy


# display the list of unique successor states of the current
# state in any order.
def succ(state, max):
    i = 0
    succ_states = []

    # these if statements attempt all possible
    # successor states, and then checks whether
    # that state already exists in the succ_states
    # list
    if empty(state, max, 0) not in succ_states:
        succ_states.insert(i, empty(state, max, 0))
        i += 1
    if empty(state, max, 1) not in succ_states:
        succ_states.insert(i, empty(state, max, 1))
        i += 1
    if fill(state, max, 0) not in succ_states:
        succ_states.insert(i, fill(state, max, 0))
        i += 1
    if fill(state, max, 1) not in succ_states:
        succ_states.insert(i, fill(state, max, 1))
        i += 1
    if xfer(state, max, 0, 1) not in succ_states:
        succ_states.insert(i, xfer(state, max, 0, 1))
        i += 1
    if xfer(state, max, 1, 0) not in succ_states:
        succ_states.insert(i, xfer(state, max, 1, 0))
        i += 1

    # goes through the list and prints all of the
    # successor states
    for x in succ_states:
        print(x)
