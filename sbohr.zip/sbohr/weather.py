""""
Sophie Bohr
CS540
Project 1 - Part 2
"""
import os
import math

# return the Euclidean distance between two dictionary
# data points from the data set.
def euclidean_distance(data_point1, data_point2):
    # sets the variables for the calculation
    tmax1 = data_point1.get('TMAX')
    tmin1 = data_point1.get('TMIN')
    prcp1 = data_point1.get('PRCP')

    tmax2 = data_point2.get('TMAX')
    tmin2 = data_point2.get('TMIN')
    prcp2 = data_point2.get('PRCP')

    # returns the euclidean distance for the two data points
    distance = math.sqrt((tmax2 - tmax1)**2 + (tmin2 - tmin1)**2 + (prcp2 - prcp1)**2)
    return distance


# return a list of data point dictionaries read from
# the specified file.
def read_dataset(filename):
    # if the file is valid, proceed
    if os.path.exists(filename):
        dicts = list()
        with open(filename, 'r') as f:
            # read each line in the file
            line = f.readline()
            while line:
                # if it's the end of the file, break
                if len(line.strip()) == 0:
                    break
                else:
                    # split the line by space, then parse each
                    # value into a proper variable
                    info = line.split()
                    date = info[0]
                    prcp = float(info[1])
                    tmax = float(info[2])
                    tmin = float(info[3])
                    rain = info[4]
                    # create a dictionary entry with all the info
                    dictionary = {'DATE': date, 'TMAX': tmax, 'PRCP': prcp, 'TMIN': tmin, 'RAIN': rain}
                    # add that entry to the list of dictionary entries
                    dicts.append(dictionary)

                line = f.readline()
        # close the file and return the list of dictionary entries
        f.close
        return dicts
    else:
        print("ERROR: Cannot open file.")


# return a prediction of whether it is raining or not
# based on a majority vote of the list of neighbors.
def majority_vote(nearest_neighbors):
    # True will be +1, False will be -1, so if majority ends
    # up being negative return FALSE, if majority is positive
    # return TRUE, and if it's zero return TRUE
    majority = 0
    for dict in nearest_neighbors:
        if dict.get('RAIN') == 'TRUE':
            majority += 1
        if dict.get('RAIN') == 'FALSE':
            majority -= 1

    if majority >= 0:
        return 'TRUE'
    else:
        return 'FALSE'


# using the above functions, return the majority vote
# prediction for whether it's raining or not on the
# provided test point.
def k_nearest_neighbors(filename, test_point, k):
    dicts = read_dataset(filename)
    pairs = []
    # go through each entry and calculate its
    # euclidean distance from the test point,
    # then store the distance along with the
    # entry in a pair in the pairs array
    for cur_point in dicts:
        cur_dist = euclidean_distance(cur_point, test_point)
        pair = [cur_dist, cur_point]
        pairs.append(pair)

    # sort the pairs array in ascending order
    # according to the distance
    sorted_pairs = sorted(pairs, key=lambda x: x[0])
    nearest_neighbors = []

    # add the first k dictionary entries in the pairs
    # array, which have the smallest distances, to the
    # nearest_neighbors array
    for i in range(k):
        new_pair = sorted_pairs[i]
        nearest_neighbors.append(new_pair[1])

    # return the majority vote of these dictionary entries
    return majority_vote(nearest_neighbors)
